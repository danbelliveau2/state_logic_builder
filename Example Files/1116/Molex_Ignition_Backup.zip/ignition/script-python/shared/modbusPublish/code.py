
# Copyright 2024 Automation Professionals, LLC <sales@automation-pros.com>
#
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
#
#   1. Redistributions of source code must retain the above copyright notice,
#      this list of conditions and the following disclaimer.
#   2. Redistributions in binary form must reproduce the above copyright notice,
#      this list of conditions and the following disclaimer in the documentation
#      and/or other materials provided with the distribution.
#   3. The name of the author may not be used to endorse or promote products
#      derived from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
# WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
# MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
# SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
# OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
# IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
# OF SUCH DAMAGE.

# Requires later.py for jython tracebacks, queueUtil.py for low-latency batch
# processing of tag events, and the Integration Toolkit module
# for its robust persistent globals support.  The latter can be approximated with
# system.util.getGlobals() if the Integration Toolkit is not available.

import re

from com.inductiveautomation.ignition.common.config import BasicProperty
from com.inductiveautomation.ignition.common.sqltags.model.TagProp import OPCItemPath
from java.lang import String, System
from java.util import LinkedList

logger = system.util.getLogger(system.util.getProjectName() + "." + __name__)


sourceTagPublishTargetCache = system.util.globalVarMap('sourceTagPublishTarget')
"""Keys are absolute tag path strings, including provider.  Values are target
OPC Item Path strings."""

slavePublishQueue = queueUtil.WrappedBlockingQueue('slavePublish', 10000)

warnOnce = True

# Call this from a one-liner in tag valueChange events, passing all args.
def enqSlavePublish(tag, tagPath, previousValue, currentValue, initialChange, missedEvents):
	global warnOnce
	# Tag valueChange event passes its args to this function, plus the prefix of the target slave.
	# Assemble the elements needed for processing.
	entry = (tagPath, currentValue, initialChange, missedEvents)
	if not slavePublishQueue.offer(entry):
		# Failed to enqueue.
		if warnOnce:
			warnOnce = False
			logger.warnf("slavePublishQueue full for tag valueChange with %s %s", tagPath, currentValue)

# Rely on tag custom properties to determine the target OPC item path for
# a given tag.  Two custom properties are recognized, in this order:
#
# publishOpcItem:  String containing an explicit OPC Item Path.  Source tag can be
# anything at all, not necessarily an OPC tag.
#
# publishOpcPrefix: String containing the beginning of an OPC Item Path, at least
# including the bracket-delimited device name.  Optionally including a unit address
# with dot delimiter, and optionally including a memory area identifier: C, DI, IR, HR, XR.
# Source tag must have an opcItemPath property, which will be parsed, then substitutions
# applied to yield the target path.  Whatever follows the original memory area ID will
# pass through to the target item path.

publishOpcItemProp = BasicProperty('publishOpcItem', String)
publishOpcPrefixProp = BasicProperty('publishOpcPrefix', String)

modbusOpcParse = re.compile(r'(ns=1;s=)?(\[[^]]+\])(\d+\.)?((C|DI|IR|HR|XR)(.*))?')
def getPublishTarget(tagPath):
	propPaths = [tagPath+p for p in ('.publishOpcItem', '.publishOpcPrefix', '.opcItemPath')]
	item, prefix, srcItem = [qv.value for qv in system.tag.readBlocking(propPaths)]
	if item:
		return item
	if prefix and srcItem:
		parsedPrefix = modbusOpcParse.match(prefix)
		dev, unit, area = parsedPrefix.group(2, 3, 5)
		parsedSource = modbusOpcParse.match(srcItem)
		oUnit, oArea, suffix = parsedSource.group(3, 5, 6)
		if dev and oArea and suffix:
			return dev + (("" if oUnit is None else oUnit) if unit is None else unit) + (oArea if area is None else area) + suffix
	# An empty string marker indicates unknown.
	return ""
#

opcServer = "Ignition OPC UA Server"

# Not using the drainEvents decorator factory as this procedure will bulk drain
# the events to construct as single multi-valued call to system.opc.writeValues().
# All targets are presumed to be in the above OPC server.
#
# Call this from a gateway fixed interval timer event, preferably with a dedicated thread.
# Use the debug logger to evaluate your workload, if necessary.
def drainSlavePublish():
	ts0 = System.nanoTime()
	workList = LinkedList()
	slavePublishQueue._queue.drainTo(workList)
	sources = []
	opcItems = []
	opcValues = []
	for tagPath, currentValue, initialChange, missedEvents in workList:
		targetItem = sourceTagPublishTargetCache.get(tagPath)
		if initialChange or targetItem is None:
			targetItem = getPublishTarget(tagPath)
			sourceTagPublishTargetCache[tagPath] = targetItem
			if targetItem == "":
				logger.warnf("Cannot publish tag %s, unable to determine target", tagPath)
		# Only write when target item is not empty, and a value is present
		if targetItem and currentValue.value is not None:
			sources.append(tagPath)
			opcItems.append(targetItem)
			opcValues.append(currentValue.value)
	# Now have a big list to write
	qList = system.opc.writeValues(opcServer, opcItems, opcValues)
	# Log any failed writes at debug level.
	for quality, source, item, val in zip(qList, sources, opcItems, opcValues):
		if not quality.good:
			logger.debugf("%s write %s to %s from %s", quality, val, item, source)
	ts1 = System.nanoTime()
	millis = 0.000001 * (ts1 - ts0)
	logger.debugf("Bulk write of %d items took %.2fms", len(sources), millis)
#

#
# kate: tab-width 4; indent-width 4; tab-indents on; dynamic-word-wrap off; indent-mode python; line-numbers on;
#
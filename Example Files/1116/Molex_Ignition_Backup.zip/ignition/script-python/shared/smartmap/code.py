# Convenience functions for Ignition development, typically loaded
# as "shared.smartmap"
#
# Copyright 2021 Automation Professionals, LLC <sales@automation-pros.com>
#
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
#
#   1. Redistributions of source code must retain the above copyright notice,
#      this list of conditions and the following disclaimer.
#   2. Redistributions in binary form must reproduce the above copyright notice,
#      this list of conditions and the following disclaimer in the documentation
#      and/or other materials provided with the distribution.
#   3. The name of the author may not be used to endorse or promote products
#      derived from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
# WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
# MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
# SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
# OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
# IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
# OF SUCH DAMAGE.

#----------
# Handy tool for objects as "bags of properties"
# by Peter Norvig, enhanced as a subclass of dict() by Philip J. Turmel
# http://norvig.com/python-iaq.html
class SmartMap(dict):
	def __repr__(self):
		args = []
		for (k,v) in self.items():
			if isinstance(v, basestring):
				args.append('%s=%s' % (k, v))
			else:
				try:
					z = len(v)
					args.append('%s=%s' % (k, type(v)))
				except:
					args.append('%s=%s' % (k, repr(v)))
		return 'SmartMap(%s)' % ', '.join(args)
	def __str__(self):
		args = []
		for k,v in self.items():
			if isinstance(v, basestring):
				args.append('%s=%s' % (k, v))
			else:
				try:
					z = len(v)
					args.append('%s=%s' % (k, repr(v)))
				except:
					args.append('%s=%s' % (k, str(v)))
		return 'SmartMap(%s)' % ', '.join(args)
	def clone(self):
		return type(self)(**self)
	def __getattr__(self, attr):
		if attr.startswith('__'):
			raise AttributeError(attr)
		if attr in self:
			return self[attr]
		return None
	def __setattr__(self, attr, val):
		if attr.startswith('__'):
			super.__setattr__(self, attr, val)
		self[attr] = val

#
# kate: tab-width 4; indent-width 4; tab-indents on; dynamic-word-wrap off; indent-mode python; line-numbers on;
#
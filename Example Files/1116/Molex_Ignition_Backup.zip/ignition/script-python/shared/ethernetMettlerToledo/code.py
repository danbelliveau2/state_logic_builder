# Ethernet Mettler Toledo Data Server Continuous Output monitor
#
# Copyright 2018-2020 Automation Professionals, LLC <sales@automation-pros.com>
#
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
#
#   1. Redistributions of source code must retain the above copyright notice,
#      this list of conditions and the following disclaimer.
#   2. Redistributions in binary form must reproduce the above copyright notice,
#      this list of conditions and the following disclaimer in the documentation
#      and/or other materials provided with the distribution.
#   3. The name of the author may not be used to endorse or promote products
#      derived from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
# WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
# MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
# SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
# OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
# IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
# OF SUCH DAMAGE.

# Use this script in combination with the client background thread management
# script "clientserial.py".  Load this as project.ethToledo or similar.

# system.tag.write('[Client]someFolder/Port', '192.168.1.101:1701')
# project.clientserial.background(project.ethToledo.monitorEMT, 'someFolder')

import re
from java.lang import String
from java.util import Date
from java.net import InetAddress, InetSocketAddress
from java.nio import ByteBuffer, CharBuffer
from java.nio.channels import SocketChannel
from java.nio.charset import StandardCharsets

#----------
# Handy tool for objects as "bags of properties"
# by Peter Norvig, enhanced as a subclass of dict() by Philip J. Turmel
# http://norvig.com/python-iaq.html
class SmartMap(dict):
	def __repr__(self):
		args = []
		for (k,v) in self.items():
			try:
				z = len(v)
				args.append('%s=%s' % (k, type(v)))
			except:
				args.append('%s=%s' % (k, repr(v)))
		return 'SmartMap(%s)' % ', '.join(args)
	def __str__(self):
		args = []
		for k,v in self.items():
			try:
				z = len(v)
				args.append('%s=%s' % (k, repr(v)))
			except:
				args.append('%s=%s' % (k, str(v)))
		return 'SmartMap(%s)' % ', '.join(args)
	def clone(self):
		return type(self)(**self)
	def __getattr__(self, attr):
		if attr.startswith('__'):
			raise AttributeError(attr)
		if attr in self:
			return self[attr]
		return None
	def __setattr__(self, attr, val):
		if attr.startswith('__'):
			super.__setattr__(self, attr, val)
		self[attr] = val
#
monitorEMTLogger = system.util.getLogger('monitorEMT')
#
socketmap = {}
#
commands = {
	'tare':  'wc0101',
	'clear': 'wc0102',
	'zero':  'wc0104'
}
#
bbSize = 100
#
def debugBB(bb):
	h = []
	for i in xrange(bb.limit()):
		byte = bb.get(i)
		h.append("%02x" % (byte & 0xff))
	monitorEMTLogger.info(' '.join(h))
#
def bbToString(bb):
	return StandardCharsets.ISO_8859_1.decode(bb).toString()
#
def writeZero(ctPath):
	data = socketmap.get(ctPath)
	if data:
		writeEMTScaleCommand(data.ch, 'zero')
	else:
		raise RuntimeError("No scale socket open")
#
def writeClear(ctPath):
	data = socketmap.get(ctPath)
	if data:
		writeEMTScaleCommand(data.ch, 'clear')
	else:
		raise RuntimeError("No scale socket open")
#
def writeTare(ctPath):
	data = socketmap.get(ctPath)
	if data:
		writeEMTScaleCommand(data.ch, 'tare')
	else:
		raise RuntimeError("No scale socket open")
#
def writeEMTScaleCommand(ch, cmd):
	sdvalue = commands.get(cmd)
	if sdvalue:
		monitorEMTLogger.info('Sending %s command. Setting sd value %s to 1' % (cmd, sdvalue))
		ch.write(ByteBuffer.wrap(String('write %s=1\r' % sdvalue).getBytes(StandardCharsets.ISO_8859_1)))
#
def writeEMTCommand(conn, line):
	if line.startswith('53 Ready for user'):
		monitorEMTLogger.info('Logging in as admin.')
		conn.ch.write(ByteBuffer.wrap(String('user admin\r').getBytes(StandardCharsets.ISO_8859_1)))
	elif line.startswith('12 Access OK'):
		monitorEMTLogger.info('Initiating contout.')
		conn.ch.write(ByteBuffer.wrap(String('contout\r').getBytes(StandardCharsets.ISO_8859_1)))
	elif 'CONTOUT' in line:
		monitorEMTLogger.info('Continuous output initiated: %s' % line)
		conn.coactive = True
	elif line.startswith('83 Command not recognized'):
		monitorEMTLogger.error('Invalid command given. Closing socket.')
		conn.ch.close()
#
def buildLine(conn, bb):
	line = ''
	inLine = False
	bb.limit(bb.position())
	bb.position(0)
	while bb.hasRemaining():
		byte = bb.get()
		if inLine:
			if conn.coactive:
				if byte == 10:
					bb.compact()
					return line
			else:
				if byte == 62:
					line += chr(byte)
					bb.compact()
					return line
		else:
			if byte in [10, 13, 0]:
				continue
			inLine = True
		line += chr(byte)
	bb.position(bb.limit())
	bb.limit(bb.capacity())
	return None
#
toledoHeaders = ["t_stamp", "Weight", "Tare", "IsNet", "Overload", "Motion", "kg", "PowerUp", "Print", "Expand", "PrevWeight", "PrevMotion"]
#
contoutre = re.compile(r'00C\d{3} \x02.{3}\s+\d+\s+\d+')
#
def monitorEMT(ctPath, myThread):
	system.tag.write('[Client]%s/LastError' % ctPath, '')
	port = system.tag.read('[Client]%s/Port' % ctPath).value
	parts = port.rsplit(':', 1)
	if len(parts) > 1:
		print 'Socket Address %s:%s' % (parts[0], parts[1])
		sa = InetSocketAddress(parts[0], int(parts[1]))
	else:
		# Default port number found in IND570 manual section 3.8.8.1
		print 'Socket Address %s Default Port 1701' % parts[0]
		sa = InetSocketAddress(parts[0], 1701)
	
	data = socketmap.get(ctPath)
	if data:
		try:
			data.ch.close()
		except:
			pass

	data = SmartMap(sa=sa, ch=SocketChannel.open(), port=port, ctPath=ctPath, reqids={}, subs={}, listener=myThread, updating=True, coactive=False)
	socketmap[ctPath] = data
	data.ch.configureBlocking(True)
	data.ch.connect(sa)
	
	monitorEMTLogger.info('Connected to %s, reading lines.' % system.tag.read('[Client]%s/Port' % ctPath).value)
	
	lineBuffer = ByteBuffer.allocate(bbSize)
	oldRow = [Date()]
	
	try:
		conditionTags = ['[Client]%s/%s' % (ctPath, x) for x in ['Port', 'Thread']]
		while [x.value for x in system.tag.readAll(conditionTags)] == [port, myThread]:
			if lineBuffer.hasRemaining():
				data.ch.configureBlocking(False)
				n = data.ch.read(lineBuffer)
			data.ch.configureBlocking(True)
			
			line = buildLine(data, lineBuffer)
			if not line:
				lineBuffer.limit(lineBuffer.position()+1)
				n = data.ch.read(lineBuffer)
				lineBuffer.limit(lineBuffer.capacity())
				continue
			#debugBB(lineBuffer)
			
			mo = contoutre.search(line)
			if mo is None:
				monitorEMTLogger.debug('Line is not contout: %s' % line)
			
			monitorEMTLogger.debug('line: %s' % line)
			
			if line[-1] == '>':
				monitorEMTLogger.debug('Command prompt read from socket channel.')
				writeEMTCommand(data, line)
			elif data.coactive and mo:
				system.tag.write('[Client]%s/LastTraffic' % ctPath, Date())
				
				StatA, StatB, StatC = [ord(x) for x in line[8:11]]
				
				#debugBB(lineBuffer)
				
				monitorEMTLogger.debug('StatA: %s|%02x' % (chr(StatA), (StatA & 0xff)))
				monitorEMTLogger.debug('StatB: %s|%02x' % (chr(StatB), (StatB & 0xff)))
				monitorEMTLogger.debug('StatC: %s|%02x' % (chr(StatC), (StatC & 0xff)))
				
				weightString = line.split()[-2]
				N = float(int(weightString))
				if StatB & 0x02:
					N = -N
				
				tareString = line.split()[-1]
				z = float(int(tareString))
				
				DP = (StatA & 0x07) - 2
				if DP:
					scale = 0.1 ** DP
					N *= scale
					z *= scale
				
				previous = system.tag.read('[Client]%s/WeightData' % ctPath).value
				prevWeight = 0
				prevMotion = True
				try:
					prevWeight = previous.getValueAt(0, 'Weight')
					prevMotion = previous.getValueAt(0, 'Motion')
				except:
					pass
				
				isNet = bool(StatB & 0x01)
				overload = bool(StatB & 0x04)
				inMotion = bool(StatB & 0x08)
				isKG = bool(StatB & 0x10)
				zeroNotCaptured = bool(StatB & 0x40)
				printRequest = bool(StatC & 0x08)
				expandData = bool(StatC & 0x10)

				row = [Date(), N, z, isNet, overload, inMotion, isKG, zeroNotCaptured, printRequest, expandData, prevWeight, prevMotion]
				if row[1:] != oldRow[1:] or (row[0].time - oldRow[0].time) > 500:
					oldRow = row
					result = system.dataset.toDataSet(toledoHeaders, [row])
					system.tag.write('[Client]%s/WeightData' % ctPath, result)
	finally:
		del socketmap[ctPath]
		data.ch.close()
#
# Caching Dynamic Query Implementation.  Expected to be
# loaded as "shared.query" in Ignition v7.9 or in the root of your
# inheritance tree as just "query".
#
# Copyright 2021 Automation Professionals, LLC <sales@automation-pros.com>
#
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
#
#   1. Redistributions of source code must retain the above copyright notice,
#      this list of conditions and the following disclaimer.
#   2. Redistributions in binary form must reproduce the above copyright notice,
#      this list of conditions and the following disclaimer in the documentation
#      and/or other materials provided with the distribution.
#   3. The name of the author may not be used to endorse or promote products
#      derived from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
# WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
# MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
# SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
# OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
# IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
# OF SUCH DAMAGE.
#
# later.py is a prerequisite.  As "shared.later" in v7.9 or just as "later".
#
from java.util import Date

columnWhitelistByTable = {}

def getWhitelistedColumns(dsn, table):
	# columns = columnWhitelistByTable.get((dsn, table)): # Original code. Had this colon, which caused syntax errors to be thrown. D.E.S. 2024-12-003	
	columns = columnWhitelistByTable.get((dsn, table))
	if columns:
		return columns
	pyds = system.db.runPrepQuery("Select columnname From informationschema.tables where tablename=?", [table], dsn)
	columns = [row[0] for row in pyds]
	columns.sort()
	columnWhitelistByTable[(dsn, table)] = columns
	return columns

# Each
myQueryCache = {}

operators = ('<', '<=', '=', '>', '>=', '!=', '<>')

# payload is expected to have dsn, table, criteria, and ordering keys.
# criteria is a dictionary of tuples keyed by column name.  Each tuple
# is an operator, value pair.
# ordering is a list of column names, possibly with " desc" appended.
# payload may have a cacheFor key specifying seconds.  Defaults to five
# minutes.

# Call this from a gateway message handler, passing the payload inward
# and return this function's return value.  Like so:
#
#   return query.doDynamicQuery(payload)
#
def doDynamicQuery(payload):
	cacheFor = int(payload.get('cacheFor', 300))
	dsn, table, criteria, ordering = payload['dsn'], payload['table'], payload['criteria'], payload['ordering']

	# Get a copy of the list of criteria items and sort
	# them so the cache key is deterministic.
	items = criteria.items()
	items.sort()
	
	cacheKey = tuple([dsn, table]+[x for (c, (o, v)) in items for x in [c, o, v]]+ordering)
	cacheEntry = myQueryCache.get(cacheKey)
	now = Date()
	if cacheEntry:
		future, expires = cacheEntry
		if now.before(expires):
			return future.get()

	columnWhiteList = getWhitelistedColumns(dsn, table)
	cols = [c for (c, (o, v)) in items] + [(c[:-5] if c.endswith(' desc') else c) for c in ordering]
	ops = [o for (c, (o, v)) in items]
	if all([(c in columnWhiteList) for c in cols]):
		if all([(o in operators) for o in ops]):
			expires = Date(now.time + 1000L * cacheFor)
			sql = 'Select * From "%s"' % table
			args = []
			whereList = ['"%s" %s ?' % (c, o) for (c, (o, v)) in items]
			if whereList:
				sql += " Where " + (" And ".join(whereList))
				args += [v for (c, (o, v)) in items]
			if ordering:
				sql += " Order By " + (", ".join(ordering))
			try:
				later = shared.later
			except:
				pass
			future = later.callAsync(system.db.runPrepQuery, sql, args, dsn)
			myQueryCache[cacheKey] = (future, expires)
			return future.get()
		raise ValueError("Unsupported Operator")
	raise ValueError("Invalid column")

# Call the following from a gateway timer script once a minute or so.
def pruneCache():
	now = Date()
	#for k, (f, e) in myQueryCache.items() # Original code. Did not have a colon, which caused syntax errors to be thrown. D.E.S. 2024-12-003
	for k, (f, e) in myQueryCache.items():
		if now.after(e):
			myQueryCache.pop(k, None)
#
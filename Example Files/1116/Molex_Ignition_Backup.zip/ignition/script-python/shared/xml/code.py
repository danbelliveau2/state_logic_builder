# Convenience functions for Ignition development, typically loaded
# as "shared.xml"
#
# Copyright 2016-2022 Automation Professionals, LLC <sales@automation-pros.com>
#
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
#
#   1. Redistributions of source code must retain the above copyright notice,
#      this list of conditions and the following disclaimer.
#   2. Redistributions in binary form must reproduce the above copyright notice,
#      this list of conditions and the following disclaimer in the documentation
#      and/or other materials provided with the distribution.
#   3. The name of the author may not be used to endorse or promote products
#      derived from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
# WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
# MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
# SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
# OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
# IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
# OF SUCH DAMAGE.

import jarray
from collections import OrderedDict

from java.io import ByteArrayInputStream, ByteArrayOutputStream, StringWriter
from java.nio.charset import StandardCharsets

from javax.xml.parsers import DocumentBuilderFactory, SAXParserFactory
from javax.xml.transform import TransformerFactory, OutputKeys
from javax.xml.transform.dom import DOMSource
from javax.xml.transform.stream import StreamResult

from org.xml.sax.helpers import AttributesImpl, DefaultHandler

xmlFactory = DocumentBuilderFactory.newInstance()
xmlFactory.setNamespaceAware(True)
xmlFactory.setIgnoringComments(True);
xmlFactory.setCoalescing(True);
xmlFactory.setExpandEntityReferences(True);

def inputToDoc(source):
	"""Process an input stream or input source as XML into an XML Document,
	per org.w3c.dom.Document.  'source' may be an java.io.InputStream,
	java.io.InputSource, or java.io.File containing XML, or a string URI
	pointing at XML content."""
	return xmlFactory.newDocumentBuilder().parse(source)

def bytesToDoc(b):
	return inputToDoc(ByteArrayInputStream(b))

def strToBytes(s):
	bb = StandardCharsets.UTF_8.encode(s)
	b = jarray.zeros(bb.limit(), 'b')
	bb.get(b)
	return b
	
def strToDoc(s):
	"""Convert a string containing XML to an XML Document, per
	org.w3c.dom.Document.  Must be wrapped in a Stream to avoid
	interpretation as a URI."""
	return bytesToDoc(strToBytes(s))

def _transformer():
	xmlTransformer = TransformerFactory.newInstance().newTransformer()
	xmlTransformer.setOutputProperty(OutputKeys.INDENT, "yes");
	xmlTransformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes")
	xmlTransformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
	return xmlTransformer

def docToOutput(doc, sink):
	"""Send a document to a target file, URI, or output stream compatible
	with a StreamResult constructor."""
	_transformer().transform(DOMSource(doc), StreamResult(sink))

def docToStr(doc):
	"""Convert an XML Document to a minimal multiline-string"""
	writer = StringWriter()
	docToOutput(doc, writer)
	return writer.toString()

def docToBytes(doc):
	baos = ByteArrayOutputStream()
	docToOutput(doc, baos)
	return baos.toByteArray()

def strThroughHandler(s, handler = None):
	if handler is None:
		handler = VisionSaxHandler()
	spf = SAXParserFactory.newInstance()
	sp = spf.newSAXParser()
	xr = sp.getXMLReader()
	xr.setContentHandler(handler)
	xr.parse(ByteArrayInputStream(strToBytes(s)))
	return handler

# Pruned Element for Vision XML parsing
class VisionElement(object):
	def __init__(self, qName, attributes, component):
		self.tag = qName
		self.attrs = OrderedDict([(attributes.getQName(i), attributes.getValue(i)) for i in range(attributes.length)])
		self.id = self.attrs.get('id')
		self.sb = StringBuilder()
	def __getattr__(self, attr):
		if attr.startswith('__'):
			raise AttributeError(attr)
		return self.attrs.get(attr)

# Parse a vision XML resource (Shift-Right-Click in the Designer tree)
# to obtain the components and their binding Jython/SQL strings
#
class VisionSaxHandler(DefaultHandler):
	def __init__(self):
		self.stack = []
		self.components = OrderedDict()
		self.componentStack = []
		self.refs = {}
		self.curAdapter = None

	def startElement(uri, localName, qName, attributes):
		parent = self.componentStack[-1] if self.componentStack else None
		ve = VisionElement(qName, attribute, parent)
		print ' ' * len(self.stack), ve.tag, ve.cls
		self.stack.append(ve)
		if ve.id is not None:
			self.refs[ve.id] = ve
		if ve.tag == 'c' or (ve.tag == o and ve.cls == 'FPMIWindow'):
			self.componentStack.append(ve)
		elif ve.tag == 'o' and ve.cls and ve.cls.endswith('Adapter'):
			self.curAdapter = ve

	def characters(ch, start, length):
		sub = ch[start:start+length]
		if sub and self.stack:
			ve = self.stack[-1]
			ve.sb.append(sub)

	def endElement(uri, localName, qName):
		ve = self.stack[-1]
		ve.content = unicode(ve.sb)
		if ve.content.strip():
			print "====", ve.tag, ve.parent, ve.cls
			print ve.content
			print "===="

		del self.stack[-1:]
		if self.componentStack and ve is self.componentStack[-1]:
			del self.componentStack[-1:]
		if ve is self.curAdapter:
			self.curAdapter = None
		
#
# kate: tab-width 4; indent-width 4; tab-indents on; dynamic-word-wrap off; indent-mode python; line-numbers on;
#
# Introspection for Jython/Java
#
# Copyright 2008-2017 Automation Professionals, LLC <sales@automation-pros.com>
#
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
#
#   1. Redistributions of source code must retain the above copyright notice,
#      this list of conditions and the following disclaimer.
#   2. Redistributions in binary form must reproduce the above copyright notice,
#      this list of conditions and the following disclaimer in the documentation
#      and/or other materials provided with the distribution.
#   3. The name of the author may not be used to endorse or promote products
#      derived from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
# WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
# MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
# SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
# OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
# IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
# OF SUCH DAMAGE.

#------------
def introspect(obj):
	"""Describe the methods and properties available in the given object,
	from both the jython perspective, and the java perspective."""
	from java.lang import reflect
	result = "Python Type: %s\n" % type(obj)
	c = obj.getClass()
	basetype = str(c)
	result += "Java Type:   %s\n" % basetype
	skips = []
	for m in c.getMethods():
		try:
			newtype = str(m.getDeclaringClass())
			if newtype != basetype:
				basetype = newtype
				result +=  "\nFrom Type:   %s\n" % basetype
			mods = []
			if m.getModifiers() & reflect.Member.PUBLIC:
				mods.append('public')
			for a in m.getTypeParameters():
				mods.append(str(a))
			rt = str(m.getReturnType())
			if len(rt)<30:
				mods.append(rt)
			mods.append(m.getName())
			pt = []
			for p in m.getParameterTypes():
				pt.append(str(p))
			skips.append(m.getName())
			result += "  M: %s(%s)\n" % (" ".join(mods), ",".join(pt))
			if len(rt)>=30:
				result += "    returns %s\n" % rt
		except Exception:
			pass
	for f in c.getFields():
		try:
			newtype = str(f.getDeclaringClass())
			if newtype != basetype:
				basetype = newtype
				result += "\nFrom Type:   %s\n" % basetype
			anno = []
			for a in f.getAnnotations():
				anno.append(str(a))
			anno.append(str(f.getType()))
			anno.append(f.getName())
			skips.append(f.getName())
			result += "  F: %s\n" % (" ".join(anno))
		except Exception:
			pass
	result += "\nFrom python dir():\n"
	for x in dir(obj):
		if x not in skips:
			try:
				if callable(getattr(obj,x)):
					result += "  Method     %s %s\n" % (x, type(getattr(obj,x)))
				else:
					y = getattr(obj, x)
					result += "  Property   %s %s %s\n" % (x, type(y), y)
			except:
				result += "  Unreadable %s\n" % x
	return result

try:
	from javax.swing import SwingUtilities
	from com.inductiveautomation.factorypmi.application.components import TemplateCanvas, TemplateRepeater
	from com.inductiveautomation.factorypmi.application.components.template import TemplateHolder
	
	def holder(comp):
		for x in (TemplateCanvas, TemplateRepeater, TemplateHolder):
			try:
				holder = SwingUtilities.getAncestorOfClass(x, comp)
			except:
				holder = None
			if holder:
				return holder
		return None
except:
	pass
# Utility functions for expression tags

# Copyright 2021 Automation Professionals, LLC <sales@automation-pros.com>
#
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
#
#   1. Redistributions of source code must retain the above copyright notice,
#      this list of conditions and the following disclaimer.
#   2. Redistributions in binary form must reproduce the above copyright notice,
#      this list of conditions and the following disclaimer in the documentation
#      and/or other materials provided with the distribution.
#   3. The name of the author may not be used to endorse or promote products
#      derived from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
# WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
# MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
# SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
# OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
# IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
# OF SUCH DAMAGE.

# Place this script in the global scripting project (or in shared scripts
# if still using Ignition v7.9.x).

from java.util import Date, LinkedList

# Call this script from an expression tag like so:
#
# objectScript("exprTagUtil.movingAvg(state, *args)",
#   {[.]periodTag}, {[.]valueTag})
#
# The value tag should be in a periodic tag group (or direct v7.9 scan
# class) for consistent timing between samples.
#
def movingAvg(state, millis, value):
	# Ignore incoming nulls
	if value is None:
		return state.get('last', None)

	# Retrieve the LinkedList holding our list of samples
	ll = state.get('ll', None)
	if ll is None:
		# First execution after tag restart.  Create the linked list.
		# this could be altered to prepopulate from tag history if
		# the provider and tag path are passed in.
		ll = LinkedList()
		state['ll'] = ll

	# Insert timestamp and the new value at the tail as a tuple.
	ts = Date()
	ll.add((ts, value))

	# Compute the clip for the given period and remove old tuples
	# from the head of the linked list.
	clip = Date(ts.time - millis)
	while True:
		pair = ll.poll()
		if pair and clip.after(pair[0]):
			continue
		# Removed one too many. Put it back at the head.
		ll.addFirst(pair)
		break

	# Make a list of just the values and compute the mean
	values = [pair[1] for pair in ll]
	if values:
		retv = float(sum(values))/len(values)
	else:
		retv = None
	state['last'] = retv
	return retv

# kate: tab-width 4; indent-width 4; tab-indents on; dynamic-word-wrap off; indent-mode python; line-numbers on;
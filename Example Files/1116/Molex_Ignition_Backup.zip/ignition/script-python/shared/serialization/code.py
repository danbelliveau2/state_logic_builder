# Helper functions for scripted java serialization within Ignition,
# typically loaded as "shared.serialization" in v7.9.
#
# Copyright 2021 Automation Professionals, LLC <sales@automation-pros.com>
#
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
#
#   1. Redistributions of source code must retain the above copyright notice,
#      this list of conditions and the following disclaimer.
#   2. Redistributions in binary form must reproduce the above copyright notice,
#      this list of conditions and the following disclaimer in the documentation
#      and/or other materials provided with the distribution.
#   3. The name of the author may not be used to endorse or promote products
#      derived from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
# WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
# MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
# SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
# OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
# IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
# OF SUCH DAMAGE.

from java.io import ByteArrayInputStream, ByteArrayOutputStream, ObjectInputStream, ObjectOutputStream, StringWriter, PrintWriter

# Serialize one or more objects into a byte array
def objectsToBytes(*objects):
	baos = ByteArrayOutputStream()
	oos = ObjectOutputStream(baos)
	for o in objects:
		oos.writeObject(o)
	oos.flush()
	return baos.toByteArray()

# Reconstruct one or more serialized objects from a byte array
# Always returned as a list
def bytesToObjects(ba):
	bais = ByteArrayInputStream(ba)
	ois = ObjectInputStream(bais)
	result = []
	while True:
		try:
			result.append(ois.readObject())
		except:
			break
	return result

# Stringify a java throwable for transmission over a network
def stringException(t):
	sw = StringWriter()
	pw = PrintWriter(sw)
	t.printStackTrace(pw)
	pw.flush()
	return str(sw)

#
# kate: tab-width 4; indent-width 4; tab-indents on; dynamic-word-wrap off; indent-mode python; line-numbers on;
#

# Copyright 2024 Automation Professionals, LLC <sales@automation-pros.com>
#
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:
#
#   1. Redistributions of source code must retain the above copyright notice,
#      this list of conditions and the following disclaimer.
#   2. Redistributions in binary form must reproduce the above copyright notice,
#      this list of conditions and the following disclaimer in the documentation
#      and/or other materials provided with the distribution.
#   3. The name of the author may not be used to endorse or promote products
#      derived from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
# WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
# MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
# SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
# OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
# IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
# OF SUCH DAMAGE.

# Requires later.py for jython tracebacks, and the Integration Toolkit module
# for its robust persistent globals support.  The latter can be approximated with
# system.util.getGlobals() if the Integration Toolkit is not available.

"""Persistent Queue Management, particularly for tag event processing offload.

Use persistent global queues to hand data from contexts that require very
low latency, like tag value change events, to be processed in contexts that
can tolerate waiting for external resources.  The underlying BlockingQueue can
be safely "wrapped" and accessed in multiple contexts concurrently.

This script should be placed in an inheritable project, bg_common if using
the scheme described here:

https://forum.inductiveautomation.com/t/where-do-should-gateway-scripts-live-with-respect-to-an-inherited-project-structure/83460/3

Typical usage in a library script in the global scripting project for tag events:

processABCqueue = queueUtil.WrappedBlockingQueue('processABC', 100)

# Call this from a one-liner in tag valueChange events, passing all args.
def enqueueABC(tag, tagPath, previousValue, currentValue, initialChange, missedEvents):
	# Tag valueChange event just passes its args to this function.
	# Assemble the elements needed for processing.
	entry = (tagPath, currentValue, initialChange, missedEvents)
	if not processABCqueue.offer(entry):
		# Failed to enqueue.  Perhaps set a tag to stop the process. Or
		# drop the event on the floor.
		pass

Typical usage in a library script in a leaf project under bg_common for
a timer event:

processABCqueue = queueUtil.WrappedBlockingQueue('processABC', 100)

@queueUtil.drainEvents(processABCqueue, 100, 'Process ABC')
def processABC(entry):
	# Unpack the entry to its components.
	tagPath, currentValue, initialChange, missedEvents = entry
	# Do whatever is needed.

# Call processABC() without args in one or more timer events at an
# appropriate pace.
"""

from java.lang import Throwable
from java.util.concurrent import LinkedBlockingQueue

logger = system.util.getLogger(system.util.getProjectName() + "." + __name__)

managementMap = system.util.globalVarMap('queueUtilPersistence')
"""All wrapped queues are distinguished by their string keys in this map."""

class WrappedBlockingQueue(object):
	"""Delegating wrapper for a LinkedBlockingQueue.

	This wrapper safely instanciates a persistent global queue with a
	given capacity, if not already present.  It exposes the minimum
	needed methods for the intended usage.

	Attributes:
		key (str): The initialized key, saved for introspection.
		_queue (LinkedBlockingQueue): delegate for all operations.
	"""

	def __init__(self, key, capacity):
		"""Wrap an existing persistent queue, or construct it.

		Args:
			key (str): Unique identifier--connects instances across contexts.
			capacity (int): Capacity to supply to LinkedBlockingQueue if needed.
		"""
		self.key = key
		# Try to obtain existing queue in fast path, avoiding unnecessary creation.
		self._queue = managementMap.get(key)
		if self._queue is None:
			# Didn't already exist.  Racing thread might beat this thread, so
			# inject fresh queue into map via .setdefault().
			self._queue = managementMap.setdefault(key, LinkedBlockingQueue(capacity))

	def poll(self):
		"""Get oldest entry from queue, if any.
		
		Delegates safely to LinkedBlockingQueue.
		
		Returns:
			object: entry from head of queue, or None if empty.
		"""
		return self._queue.poll()

	def offer(self, entry):
		"""Pushes new entry onto queue, if space is available.
		
		Delegates safely to LinkedBlockingQueue.

		Args:
			entry (object): New entry.  Must not be null.

		Returns:
			bool: True on success, false on queue full.
		"""
		return self._queue.offer(entry)

def drainEvents(queue, maxPer, logPrefix):
	"""Decorator that provides queue iteration and simple error handling.

	Args:
		queue (WrappedBlockingQueue): The queue to iterate through.
		maxPer (int): Limit to iteration.  Typically similar to queue capacity.
		logPrefix (str): Message to include with logged throwables and exceptions.

	The resulting function should be called from a gateway timer event at a pace
	that keeps the queue from filling up and meets the typical latency requirements
	of the application.

	Returns:
		callable: Decorated function.  Note that the resulting callable TAKES NO ARGS.
	"""
	def innerDecorator(f):
		def innerDrain():
			processed = 0
			entry = queue.poll()
			while entry:
				try:
					f(entry)
				except Throwable, t:
					logger.warn(logPrefix, t)
				except Exception, e:
					logger.warn(logPrefix, later.PythonAsJavaException(e))
				processed += 1
				if processed > maxPer:
					break
				entry = queue.poll()
		return innerDrain
	return innerDecorator

#
# kate: tab-width 4; indent-width 4; tab-indents on; dynamic-word-wrap off; indent-mode python; line-numbers on;
#
from java.lang import System
import java.lang.Exception
import traceback

base_logger = system.util.getLogger("myLogger")

def logData(newLot):
	myLogger = base_logger
	try:
		server = "Ignition OPC UA Server"
		opcPath = "[default]Molex/Debug/TempLogging/CSV/"
		UIDall = []
		headers = [
		"DateTime",
		"Temperature",
		]

		pathArray = [
#		"{}Date".format(opcPath),
		(opcPath + "Timestamp"),
		(opcPath + "PartTemperature"),
		]
		

		fileName = system.tag.read("[default]Molex/Debug/TempLogging/Date").value
		opcValues = sdc.tag.read(pathArray, False)

		#recipeRow = [i,opcValues]
		UIDall.append(opcValues)
			
		# get data
		dataset = system.dataset.toDataSet(headers, UIDall)
		
		# convert to csv 
		if (newLot == True):
			CSVdata = system.dataset.toCSV(dataset)
		else:
			CSVdata = system.dataset.toCSV(dataset, False)
		# write file to new csv if new lot entry
		if (newLot == True):
			system.file.writeFile("C:\\Users\\SDC\\Desktop\\TemperatureTracking\\{}.csv".format(fileName), CSVdata)
		#append row to current file if not new lot entry
		else:
			system.file.writeFile("C:\\Users\\SDC\\Desktop\\TemperatureTracking\\{}.csv".format(fileName), CSVdata, True)
	except java.lang.Throwable, e:
		# Handle the java exception
		print "Java exception occurred:" + str(e)
		myLogger.error(traceback.format_exc())
	except Exception, e:
	    # Handle general errors
		print "A general exception occurred:" + str(e)
		myLogger.error(traceback.format_exc())
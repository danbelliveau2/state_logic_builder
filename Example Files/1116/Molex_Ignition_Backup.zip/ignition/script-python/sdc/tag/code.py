from java.lang import System
import java.lang.Exception
import traceback

base_logger = system.util.getLogger("myLogger")

def write(paths, values, async=False):
	myLogger = base_logger
	if async:
		system.tag.writeAsync(paths, values, lambda x: writeCallback(paths, x))
	else:
		write_return = system.tag.writeBlocking(paths, values)
		bad_writes = ["{} ({})".format(path, quality) for path, quality in zip(paths, write_return) if not quality.good]
		if bad_writes:
			myLogger.warn("failed write Blocking: {}".format(bad_writes))
		
def writeCallback(paths, write_return):
	myLogger = base_logger
	bad_writes = ["{} ({})".format(path, quality) for path, quality in zip(paths, write_return) if not quality.good]
	if bad_writes:
		myLogger.warn("failed write Async: {}".format(bad_writes))
		
def read(paths, opc=False):
	try:
		myLogger = base_logger
		if opc:
			read_return = system.opc.readValues("Ignition OPC UA Server", paths)
		else:
			read_return = system.tag.readBlocking(paths)
		#print read_return
		#print read_return[0].quality
		#for path, val in zip(paths, read_return):
		#	print path + " : " + str(val.quality)
		bad_reads = ["{} ({})".format(path, val.quality) for path, val in zip(paths, read_return) if not val.quality.good]
		#print "bad_reads: " + str(bad_reads)
		if bad_reads:
			msg = "failed " + ("OPC read:" if opc else "read Blocking:") + " {}".format(bad_reads)
			#print msg
			myLogger.warn(msg)
		else:
			read_values = [x.value for x in read_return]
			return read_values
	except java.lang.Throwable, e:
		# Handle the java exception
		print "Java exception occurred:" + str(e)
		myLogger.error(traceback.format_exc())
	except Exception, e:
	    # Handle general errors
		print "A general exception occurred:" + str(e)
		myLogger.error(traceback.format_exc())
		
def load_mem_to_current(cell_id):
   """Load recipe parameters from memory to cell/current location
   
   Param:
   	cell_id (str): Id designation of cell
   """
   # List tags to read.
   readTags = ['[{}]/Cell/Recipe/Memory/{}'.format(cell_id, x) for x in range(0,49)]
   # Read tags and extract values.
   writeValues = [x.value for x in system.tag.readBlocking(readTags)]
   # List tags to write.
   writeTags = ['[{}]/Cell/Recipe/Current/Cell/{}'.format(cell_id, x) for x in range(0,49)]
   # Write values to tags.
   system.tag.writeBlocking(writeTags, writeValues)
from java.lang import System
import java.lang.Exception
import traceback
from java.net import Socket, InetSocketAddress
from java.io import DataOutputStream

def GetZplFromDatabase(legNum, labelerNum):
	myLogger = system.util.getLogger("myLogger")
	try:
		leg = str(legNum)
		writePaths = [
			"[default]Leg_{}/DB_Transactions/PPL_Label0{}_DB_Query_Success".format(legNum, labelerNum)
			, "[default]Leg_{}/DB_Transactions/PPL_Label0{}_DB_Query_Fail".format(legNum, labelerNum)
		]
		opcTagPaths = [
			"ns=1;s=[PLC1058]Program:L{}_PPL_Label0{}.SS_Labeler.PartInfo.FromDatabase.JobID".format(legNum, labelerNum)
			, "ns=1;s=[PLC1058]Program:L{}_PPL_Label0{}.SS_Labeler.PartInfo.FromDatabase.ShopOrderID".format(legNum, labelerNum)
		]	
		readValues = [x.value for x in system.opc.readValues('Ignition OPC UA Server', opcTagPaths)]
		preLabelerJobId = readValues[0]
		preLabelerShopOrderId = readValues[1]
		partPresentAtPreLabeler = (preLabelerJobId > 0)
		
		if (partPresentAtPreLabeler):
			#Get the ZPL string from the database for the Pre-Labeler position
			query = """
				SELECT TOP 1
					ShippingLabel
				FROM OrderTable
				WHERE
					ShopOrderID = ?
					AND JobID = ?
				ORDER BY JobID;
			"""
			pyData = system.db.runPrepQuery(query, [preLabelerShopOrderId, preLabelerJobId], "HP_1058")
			#print "Leg #" + leg + " , getColumnCount: " + str(pyData.getColumnCount())
			#print "Leg #" + leg + " , getColumnNames: " + str(pyData.getColumnNames())
			#print "Leg #" + leg + " , getColumnTypes: " + str(pyData.getColumnTypes())
			#print "Leg #" + leg + " , getRowCount: " + str(pyData.getRowCount())
			rowCount = pyData.getRowCount()
			if (rowCount > 0):
				results = pyData.getValueAt(0, 0)
				sdc.tag.write(["[default]Leg_{}/DB_Transactions/PPL_Label0{}_ZPLData".format(legNum, labelerNum)], [results])
				sdc.tag.write(writePaths, [True, False], True)
			else:
				print "Get ZPL from db - Leg #{}. No rows returned for ShopOrderID: {}, JobID: {}".format(legNum, preLabelerShopOrderId, preLabelerJobId)
				sdc.tag.write(writePaths, [False, True], True)
	except java.lang.Throwable, e:
		# Handle the java exception
		print "Get ZPL from db - Leg #{} Labeler {}. Java exception occurred:{}".format(legNum, labelerNum, e)
		print "Cause: " + str(e.cause)
		myLogger.error(traceback.format_exc())
		sdc.tag.write(writePaths, [False, True], True)
	except Exception, e:
		# Handle Python Exeptions
		print "Get ZPL from db - Leg #{} Labeler {}. Python exception occurred:{}".format(legNum, labelerNum, e)
		myLogger.error(traceback.format_exc())
		sdc.tag.write(writePaths, [False, True], True)

def SendZplToLabeler(legNum, labelerNum):
	myLogger = system.util.getLogger("myLogger")
	try:
		leg = str(legNum)
		writePaths = [
			"[default]Leg_{}/StationTracking/SS_Labeler{}/From Database/HandshakeSuccess".format(legNum, labelerNum)
			, "[default]Leg_{}/StationTracking/SS_Labeler{}/From Database/HandshakeFail".format(legNum, labelerNum)
		]
		labelerJobId = system.tag.read("[default]Leg_{}/StationTracking/SS_Labeler{}/From Database/JobID".format(legNum, labelerNum)).value
		partPresentAtLabeler = (labelerJobId > 0)
	
		#Get the ZPL string from the buffer tag for the Labeler position
		zpl = system.tag.read("[default]Leg_{}/DB_Transactions/PPL_Label0{}_ZPLData".format(legNum, labelerNum)).value.encode('utf-8')
		zplStringExists = len(zpl) > 100
		
		if (zplStringExists and partPresentAtLabeler):
			if (legNum == 2):
				adr = 194 if labelerNum == 2 else 193
			else:
				adr = 94 if labelerNum == 2 else 93
			port = 9100
			printer = Socket()
			printer.connect(InetSocketAddress("172.22.52.{}".format(adr), port), 2000)
			outPrinter = DataOutputStream(printer.getOutputStream())
			outPrinter.write(zpl)
			
			outPrinter.close()
			printer.close()
			
		#Clear the ZPL buffer tag, bypass for testing
		#system.tag.write(["[default]Leg_1/DB_Transactions/PPL_Label01_ZPLData"], [""])
		
		sdc.tag.write(writePaths, [True, False], True)
	except java.lang.Throwable, e:
		# Handle the java exception
		print "Send ZPL to Labeler - Leg #{} Labeler {}. Java exception occurred:{}".format(legNum, labelerNum, e)
		print "Cause: " + str(e.cause)
		myLogger.error(traceback.format_exc())
		sdc.tag.write(writePaths, [False, True], True)
	except Exception, e:
		# Handle Python Exceptions
		print "Send ZPL to Labeler - Leg #{} Labeler {}. Python exception occurred:{}".format(legNum, labelerNum, e)
		myLogger.error(traceback.format_exc())
		sdc.tag.write(writePaths, [False, True], True)
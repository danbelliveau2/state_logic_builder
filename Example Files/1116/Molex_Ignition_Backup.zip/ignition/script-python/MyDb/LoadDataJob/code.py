from java.lang import System
import java.lang.Exception
import traceback

def GetPartInfo(legNum):
	startTime = System.nanoTime()
	myLogger = system.util.getLogger("myLogger")
	try:
		leg = str(legNum)
		writeValues = [
			-1
			,-1
			,"Get Job Start Part Info for Leg #" + leg + " script failed."
			, ''
			, ''
			, 0
			, 0
			, 0
			, -1
			, 0.0
			, ''
			, ''
		]

		pathPrefix = "[default]Leg_" + leg + "/StationTracking/4/"
		igParamTagPaths = [
			"[default]Leg_" + leg + "/DB_Transactions/ShopOrderParameters/Active_ShopOrderID"
			, "[default]Leg_" + leg + "/DB_Transactions/ShopOrderParameters/Active_SKU"
		]		
		opcTagPaths = [
			"ns=1;s=[PLC1058]L" + leg + "_StationStatus[4].PartInfo.FromDatabase.JobID"
			, "ns=1;s=[PLC1058]L" + leg + "_StationStatus[4].HeadNumber"
		]	
		# Get the tag values needed for input parameters to the stored procedure
		igParamValues = sdc.tag.read(igParamTagPaths)
		opcValues = sdc.tag.read(opcTagPaths,True)
		inParamValues = igParamValues + opcValues
		
		writePaths = [
			pathPrefix + "spResponse/NewId"
			, pathPrefix + "spResponse/ErrorCode"
			, pathPrefix + "spResponse/Message"
			, "[default]Leg_" + leg + "/DB_Transactions/ShopOrderParameters/Active_SKU"
			, pathPrefix + "From Database/SKU"
			, pathPrefix + "From Database/JobID"
			, pathPrefix + "From Database/ShopOrderID"
			, pathPrefix + "From Database/Family"
			, pathPrefix + "From Database/DatabaseID"
			, pathPrefix + "From Database/ExpectedWeight"
			, pathPrefix + "From Database/ServiceType"
			, pathPrefix + "From Database/TrackingNumber"
		]

		shopOrderId = inParamValues[0]
		activeSku = inParamValues[1]
		jobId = inParamValues[2]
		headNumber = inParamValues[3]
		#print "Get Part Info for Leg #" + leg + ". ShopOrderID: " + str(shopOrderId) + ", SKU: " + activeSku + ", JobID: " + str(jobId) + ", Head: " + str(headNumber)

		call = system.db.createSProcCall("sdcSP_GetJob")

		call.registerOutParam(1, system.db.INTEGER) #NewID
		call.registerOutParam(2, system.db.INTEGER) #intErrorCode
		call.registerOutParam(3, system.db.VARCHAR) #CustomErrMsg
		call.registerOutParam(9, system.db.INTEGER) #pJobID
		call.registerOutParam(10, system.db.INTEGER) #ShopOrderID
		call.registerOutParam(11, system.db.NVARCHAR) #SkuNew
		call.registerOutParam(12, system.db.INTEGER) #Family
		call.registerOutParam(13, system.db.BIGINT) #DatabaseID
		call.registerOutParam(14, system.db.FLOAT) #ExpectedWeight
		call.registerOutParam(15, system.db.NVARCHAR) #ServiceType
		call.registerOutParam(16, system.db.NVARCHAR) #TrackingNumber

		call.registerInParam(4, system.db.INTEGER, shopOrderId)
		call.registerInParam(5, system.db.NVARCHAR, activeSku)
		call.registerInParam(6, system.db.INTEGER, jobId)
		call.registerInParam(7, system.db.TINYINT, legNum)
		call.registerInParam(8, system.db.TINYINT, headNumber)
		
		system.db.execSProcCall(call)
		  
		# Get the output parameters
		NewId = call.getOutParamValue(1)
		ErrorCode = call.getOutParamValue(2)
		ErrMsg = call.getOutParamValue(3)
		oJobId = call.getOutParamValue(9)
		oShopOrderId = call.getOutParamValue(10)
		oSkuNew = call.getOutParamValue(11)
		oFamily = call.getOutParamValue(12)
		oDatabaseId = call.getOutParamValue(13)
		oExpectedWeight = call.getOutParamValue(14)
		oServiceType = call.getOutParamValue(15)
		oTrackingNumber = call.getOutParamValue(16)
		
		if (ErrorCode != 0):
			print "Get Part Info for Leg #" + leg + " stored procedure failed: " + ErrMsg
			writePaths = [
				pathPrefix + "spResponse/NewId"
				, pathPrefix + "spResponse/ErrorCode"
				, pathPrefix + "spResponse/Message"
			]
			writeValues = [
				NewId
				, ErrorCode
				, ErrMsg
			]
			oShopOrderId = -1
			oSkuNew = ''
		else:
			#print "Get Part Info for Leg #" + leg + " succeeded. ShopOrderID: " + str(oShopOrderId) + ", SKU: " + oSkuNew + ", JobID: " + str(oJobId)
			writeValues = [
				NewId
				, ErrorCode
				, ErrMsg
				, oSkuNew
				, oSkuNew
				, oJobId
				, oShopOrderId
				, oFamily
				, oDatabaseId
				, oExpectedWeight
				, oServiceType
				, oTrackingNumber
			]

		sdc.tag.write(writePaths, writeValues, True)
		GetFeederInfo(legNum, oShopOrderId, oSkuNew)
	except java.lang.Throwable, e:
		# Handle the java exception
		print "Get Job Part Info for Leg #" + leg + ". Java exception occurred:" + str(e)
		print "Cause: " + str(e.cause)
		myLogger.error(traceback.format_exc())
	except Exception, e:
		# Handle Python Exceptions
		print "Get Job Part Info for Leg #" + leg + ". Python exception occurred:" + str(e)
		myLogger.error(traceback.format_exc())
	finally:
		endTime = System.nanoTime()
		exeTime = 0.000001 * (endTime - startTime)
		#print "Load Part Info - Leg #{}, JobID:{}, {:.1f}ms.".format(legNum, oJobId, exeTime)

def GetFeederInfo(legNum, shopOrderId, sku):
	startTime = System.nanoTime()
	myLogger = system.util.getLogger("myLogger")
	try:
		leg = str(legNum)
		#print "Get Feeder Info for Leg #" + leg
		writeValues = [
			-1
			,-1
			,"Get Feeder Info for Leg #" + leg + " script failed."
			, False
			, -1
			, 0.0
			, False
			, -1
			, 0.0
			, False
			, -1
			, 0.0
			, False
			, -1
			, 0.0
			, False
			, -1
			, 0.0
			, False
			, False
			, False
			, False
			, False
			, True
			, False
		]

		pathPrefix = "[default]Leg_" + leg + "/StationTracking/4/"
		pathComp = "[default]Leg_" + leg + "/DB_Transactions/Components_Current/"
		inParamTagPaths = [
			pathComp + "U1_PartNumber"
			, pathComp + "U2_PartNumber"
			, pathComp + "U3_PartNumber"
			, pathComp + "U4_PartNumber"
			, pathComp + "U5_PartNumber"
			, pathComp + "M1_PartNumber"
			, pathComp + "M2_PartNumber"
			, pathComp + "M3_PartNumber"
			, pathComp + "M4_PartNumber"
		]
		# Get the tag values needed for input parameters to the stored procedure
		inParamValues = sdc.tag.read(inParamTagPaths)
		#print "Get Feeder info for Leg #" + leg + ", SKU: " + sku + ". Tags read."
		
		writePaths = [
			pathPrefix + "spResponse2/NewId"
			, pathPrefix + "spResponse2/ErrorCode"
			, pathPrefix + "spResponse2/Message"
			, pathPrefix + "From Database/US1"
			, pathPrefix + "To Database/MaterialID_US1"
			, pathPrefix + "From Database/US1Weight"
			, pathPrefix + "From Database/US2"
			, pathPrefix + "To Database/MaterialID_US2"
			, pathPrefix + "From Database/US2Weight"
			, pathPrefix + "From Database/US3"
			, pathPrefix + "To Database/MaterialID_US3"
			, pathPrefix + "From Database/US3Weight"
			, pathPrefix + "From Database/US4"
			, pathPrefix + "To Database/MaterialID_US4"
			, pathPrefix + "From Database/US4Weight"
			, pathPrefix + "From Database/US5"
			, pathPrefix + "To Database/MaterialID_US5"
			, pathPrefix + "From Database/US5Weight"
			, pathPrefix + "From Database/Media1"
			, pathPrefix + "From Database/Media2"
			, pathPrefix + "From Database/Media3"
			, pathPrefix + "From Database/Media4"
			, pathPrefix + "From Database/EnvelopeRequired"
			, pathPrefix + "From Database/HandshakeFail"
			, pathPrefix + "From Database/HandshakeSuccess"
		]

		if (shopOrderId == -1):
			sdc.tag.write(writePaths, writeValues, True) #If the calling function GetPartInfo failed, clear the data in the PLC tags.
			print "Get Feeder info for Leg #" + leg + " exiting because sdcSP_GetJob failed."
			return

		pnUS1 = inParamValues[0]
		pnUS2 = inParamValues[1]
		pnUS3 = inParamValues[2]
		pnUS4 = inParamValues[3]
		pnUS5 = inParamValues[4]
		pnM1 = inParamValues[5]
		pnM2 = inParamValues[6]
		pnM3 = inParamValues[7]
		pnM4 = inParamValues[8]
			
		call = system.db.createSProcCall("sdcSP_GetSku_ActiveFeeders")

		call.registerOutParam(1, system.db.INTEGER) #NewID
		call.registerOutParam(2, system.db.INTEGER) #intErrorCode
		call.registerOutParam(3, system.db.VARCHAR) #CustomErrMsg
		call.registerOutParam(7, system.db.BIT) #U1_Active
		call.registerOutParam(8, system.db.INTEGER) #U1_MaterialID
		call.registerOutParam(9, system.db.FLOAT) #US1Weight
		call.registerOutParam(11, system.db.BIT) #U2_Active
		call.registerOutParam(12, system.db.INTEGER) #U2_MaterialID
		call.registerOutParam(13, system.db.FLOAT) #US2Weight
		call.registerOutParam(15, system.db.BIT) #U3_Active
		call.registerOutParam(16, system.db.INTEGER) #U3_MaterialID
		call.registerOutParam(17, system.db.FLOAT) #US3Weight
		call.registerOutParam(19, system.db.BIT) #U4_Active
		call.registerOutParam(20, system.db.INTEGER) #U4_MaterialID
		call.registerOutParam(21, system.db.FLOAT) #US4Weight
		call.registerOutParam(23, system.db.BIT) #U5_Active
		call.registerOutParam(24, system.db.INTEGER) #U5_MaterialID
		call.registerOutParam(25, system.db.FLOAT) #US5Weight
		call.registerOutParam(27, system.db.BIT) #M1_Active
		call.registerOutParam(29, system.db.BIT) #M2_Active
		call.registerOutParam(31, system.db.BIT) #M3_Active
		call.registerOutParam(33, system.db.BIT) #M4_Active
		call.registerOutParam(34, system.db.BIT) #EnvelopeRequired

		call.registerInParam(4, system.db.INTEGER, shopOrderId)
		call.registerInParam(5, system.db.NVARCHAR, sku)
		call.registerInParam(6, system.db.NVARCHAR, pnUS1)
		call.registerInParam(10, system.db.NVARCHAR, pnUS2)
		call.registerInParam(14, system.db.NVARCHAR, pnUS3)
		call.registerInParam(18, system.db.NVARCHAR, pnUS4)
		call.registerInParam(22, system.db.NVARCHAR, pnUS5)
		call.registerInParam(26, system.db.NVARCHAR, pnM1)
		call.registerInParam(28, system.db.NVARCHAR, pnM2)
		call.registerInParam(30, system.db.NVARCHAR, pnM3)
		call.registerInParam(32, system.db.NVARCHAR, pnM4)
		
		system.db.execSProcCall(call)
		#print "Get Feeder info for Leg #" + leg + ", SKU: " + sku + ". Stored procedure called."

		# Get the output parameters
		NewId = call.getOutParamValue(1)
		ErrorCode = call.getOutParamValue(2)
		ErrMsg = call.getOutParamValue(3)
		oActiveUS1 = call.getOutParamValue(7)
		oMaterialIdUS1 = call.getOutParamValue(8)
		oWeightUS1 = call.getOutParamValue(9)
		oActiveUS2 = call.getOutParamValue(11)
		oMaterialIdUS2 = call.getOutParamValue(12)
		oWeightUS2 = call.getOutParamValue(13)
		oActiveUS3 = call.getOutParamValue(15)
		oMaterialIdUS3 = call.getOutParamValue(16)
		oWeightUS3 = call.getOutParamValue(17)
		oActiveUS4 = call.getOutParamValue(19)
		oMaterialIdUS4 = call.getOutParamValue(20)
		oWeightUS4 = call.getOutParamValue(21)
		oActiveUS5 = call.getOutParamValue(23)
		oMaterialIdUS5 = call.getOutParamValue(24)
		oWeightUS5 = call.getOutParamValue(25)
		oActiveM1 = call.getOutParamValue(27)
		oActiveM2 = call.getOutParamValue(29)
		oActiveM3 = call.getOutParamValue(31)
		oActiveM4 = call.getOutParamValue(33)
		oEnvelopeRequired = call.getOutParamValue(34)
		
		
		if (ErrorCode != 0):
			print "Get Feeder info for Leg #" + leg + ", SKU: " + sku + ". Stored procedure failed: " + ErrMsg
			writePaths = [
				pathPrefix + "spResponse2/NewId"
				, pathPrefix + "spResponse2/ErrorCode"
				, pathPrefix + "spResponse2/Message"
				, pathPrefix + "From Database/HandshakeFail"
				, pathPrefix + "From Database/HandshakeSuccess"
			]
			writeValues = [
				NewId
				, ErrorCode
				, ErrMsg
				, True
				, False
			]
		else:
			#print "Get Feeder info for Leg #" + leg + ", SKU: " + sku + ". Stored procedure succeeded: " + ErrMsg
			#print "Get Feeder info for Leg #" + leg + ", SKU: " + sku + ". Unstackers Active: " + str(oActiveUS1) + ", " + str(oActiveUS2) + ", " + str(oActiveUS3) + ", " + str(oActiveUS4) + ", " + str(oActiveUS5)
			writeValues = [
				NewId
				, ErrorCode
				, ErrMsg
				, oActiveUS1
				, oMaterialIdUS1
				, oWeightUS1
				, oActiveUS2
				, oMaterialIdUS2
				, oWeightUS2
				, oActiveUS3
				, oMaterialIdUS3
				, oWeightUS3
				, oActiveUS4
				, oMaterialIdUS4
				, oWeightUS4
				, oActiveUS5
				, oMaterialIdUS5
				, oWeightUS5
				, oActiveM1
				, oActiveM2
				, oActiveM3
				, oActiveM4
				, oEnvelopeRequired
				, False
				, True
			]

		sdc.tag.write(writePaths, writeValues, True)
	except java.lang.Throwable, e:
		# Handle the java exception
		print "Get Feeder info for Leg #" + leg + ", SKU: " + sku + ". Java exception occurred:" + str(e)
		print "Cause: " + str(e.cause)
		myLogger.error(traceback.format_exc())
	except Exception, e:
		# Handle Python Exceptions
		print "Get Feeder info for Leg #" + leg + ", SKU: " + sku + ". Python exception occurred:" + str(e)
		myLogger.error(traceback.format_exc())
	finally:
		endTime = System.nanoTime()
		exeTime = 0.000001 * (endTime - startTime)
		#print "Get Feeder Info - Leg #{}, SKU:{}, {:.1f}ms.".format(legNum, sku, exeTime)
		

def JobLoad_ReadInputs(legNum, stationName):
	startTime = System.nanoTime()
	myLogger = system.util.getLogger("myLogger")
	try:
		leg = str(legNum)
		
		# These tags are updated when the ShopOrderID changes.
		# Doing an OPC read isn't necessary because they update way before this function is triggered. 
		igPrefixDbSp = "[default]Leg_{}/DB_Transactions/ShopOrderParameters/".format(legNum)
		igPrefixDbCr = "[default]Leg_{}/DB_Transactions/Components_Current/".format(legNum)
		igPaths = [
			igPrefixDbSp + "Active_ShopOrderID"
			, igPrefixDbSp + "Active_SKU"
			, igPrefixDbCr + "U1_PartNumber"
			, igPrefixDbCr + "U2_PartNumber"
			, igPrefixDbCr + "U3_PartNumber"
			, igPrefixDbCr + "U4_PartNumber"
			, igPrefixDbCr + "U5_PartNumber"
			, igPrefixDbCr + "M1_PartNumber"
			, igPrefixDbCr + "M2_PartNumber"
			, igPrefixDbCr + "M3_PartNumber"
			, igPrefixDbCr + "M4_PartNumber"
		]
		
		# These tags are updated on index so doing an OPC read is necessary.
		opcPrefix = "ns=1;s=[PLC1058]L{}_StationStatus[{}].".format(legNum, stationName)
		opcPaths = [
			opcPrefix + "PartInfo.FromDatabase.JobID"
			, opcPrefix + "HeadNumber"
		]
		
		# Get the tag values needed for input parameters to the stored procedure
		igValues = sdc.tag.read(igPaths)
		opcValues = sdc.tag.read(opcPaths,True)

		writePrefix = "[default]Leg_{}/DB_Transactions/JobLoad_Inputs/".format(legNum)
		writePaths = [
			writePrefix + "Active_ShopOrderID"
			, writePrefix + "Active_SKU"
			, writePrefix + "U1_PartNumber"
			, writePrefix + "U2_PartNumber"
			, writePrefix + "U3_PartNumber"
			, writePrefix + "U4_PartNumber"
			, writePrefix + "U5_PartNumber"
			, writePrefix + "M1_PartNumber"
			, writePrefix + "M2_PartNumber"
			, writePrefix + "M3_PartNumber"
			, writePrefix + "M4_PartNumber"
			, writePrefix + "JobID"
			, writePrefix + "HeadNumber"
		]
		# Store the values to Ignition memory tags.
		# Temporary storage in case the Stored Procedure fails and needs retried.
		writeValues = igValues + opcValues
		sdc.tag.write(writePaths, writeValues)

	except java.lang.Throwable, e:
		# Handle the java exception
		ErrorMessage = "Job Load Read Inputs - Leg #{}. Java exception occurred: {}".format(legNum, e)
		print ErrorMessage
		print "Cause: " + str(e.cause)
		myLogger.error(traceback.format_exc())
		writePrefix = "[default]Leg_{}/DB_Transactions/JobLoad_Outputs/".format(legNum)
		writePaths = [writePrefix + "spResponse/NewId", writePrefix + "spResponse/ErrorCode", writePrefix + "spResponse/Message"]
		writeValues = [-1,-1, ErrorMesssage]		
	except Exception, e:
		# Handle Python Exceptions
		ErrorMessage = "Job Load Read Inputs - Leg #{}. Python exception occurred: {}".format(legNum, e)
		print ErrorMessage
		print traceback.format_exc()
		myLogger.error(traceback.format_exc())
		writePrefix = "[default]Leg_{}/DB_Transactions/JobLoad_Outputs/".format(legNum)
		writePaths = [writePrefix + "spResponse/NewId", writePrefix + "spResponse/ErrorCode", writePrefix + "spResponse/Message"]
		writeValues = [-1,-1, ErrorMesssage]				
	finally:
		endTime = System.nanoTime()
		exeTime = 0.000001 * (endTime - startTime)
		#print "Job Load Read Inputs - Leg #{}, JobID:{}, {:.1f}ms.".format(legNum, writeValues[11], exeTime)
		
def JobLoad_DbCall_PartInfo(legNum):
	startTime = System.nanoTime()
	myLogger = system.util.getLogger("myLogger")
	try:
		leg = str(legNum)

		readPrefix = "[default]Leg_{}/DB_Transactions/JobLoad_Inputs/".format(legNum)
		readPaths = [
			readPrefix + "Active_ShopOrderID"
			, readPrefix + "Active_SKU"
			, readPrefix + "JobID"
			, readPrefix + "HeadNumber"
		]		

		# Get the tag values needed for input parameters to the stored procedure
		readValues = sdc.tag.read(readPaths)
		
		shopOrderId = readValues[0]
		activeSku = readValues[1]
		jobId = readValues[2]
		headNumber = readValues[3]

		call = system.db.createSProcCall("sdcSP_GetJob")

		call.registerOutParam(1, system.db.INTEGER) #NewID
		call.registerOutParam(2, system.db.INTEGER) #intErrorCode
		call.registerOutParam(3, system.db.VARCHAR) #CustomErrMsg
		call.registerOutParam(9, system.db.INTEGER) #pJobID
		call.registerOutParam(10, system.db.INTEGER) #ShopOrderID
		call.registerOutParam(11, system.db.NVARCHAR) #SkuNew		
		call.registerOutParam(12, system.db.INTEGER) #Family
		call.registerOutParam(13, system.db.BIGINT) #DatabaseID
		call.registerOutParam(14, system.db.FLOAT) #ExpectedWeight
		call.registerOutParam(15, system.db.NVARCHAR) #ServiceType
		call.registerOutParam(16, system.db.NVARCHAR) #TrackingNumber

		call.registerInParam(4, system.db.INTEGER, shopOrderId)
		call.registerInParam(5, system.db.NVARCHAR, activeSku)
		call.registerInParam(6, system.db.INTEGER, jobId)
		call.registerInParam(7, system.db.TINYINT, legNum)
		call.registerInParam(8, system.db.TINYINT, headNumber)
		
		system.db.execSProcCall(call)
		  
		# Get the output parameters
		NewId = call.getOutParamValue(1)
		ErrorCode = call.getOutParamValue(2)
		ErrMsg = call.getOutParamValue(3)
		oJobId = call.getOutParamValue(9)
		oShopOrderId = call.getOutParamValue(10)
		oSkuNew = call.getOutParamValue(11)
		oFamily = call.getOutParamValue(12)
		oDatabaseId = call.getOutParamValue(13)
		oExpectedWeight = call.getOutParamValue(14)
		oServiceType = call.getOutParamValue(15)
		oTrackingNumber = call.getOutParamValue(16)

		writePrefix = "[default]Leg_{}/DB_Transactions/JobLoad_Outputs/".format(legNum)
		writePaths = [
			writePrefix + "spResponse/NewId"
			, writePrefix + "spResponse/ErrorCode"
			, writePrefix + "spResponse/Message"
			, writePrefix + "Sku"
			, writePrefix + "JobId"
			, writePrefix + "ShopOrderId"
			, writePrefix + "Family"
			, writePrefix + "DatabaseId"
			, writePrefix + "ExpectedWeight"
			, writePrefix + "ServiceType"
			, writePrefix + "TrackingNumber"
		]

		if (ErrorCode != 0):
			print "Job Load db Call - Get Part Info for Leg #" + leg + " stored procedure failed: " + ErrMsg
			writePaths = [
				writePrefix + "spResponse/NewId"
				, writePrefix + "spResponse/ErrorCode"
				, writePrefix + "spResponse/Message"
			]
			writeValues = [
				NewId
				, ErrorCode
				, ErrMsg
			]
			oShopOrderId = -1
			oSkuNew = ''
		else:
			#print "Job Load db Call - Get Part Info for Leg #" + leg + " succeeded. ShopOrderID: " + str(oShopOrderId) + ", SKU: " + oSkuNew + ", JobID: " + str(oJobId)
			writeValues = [
				NewId
				, ErrorCode
				, ErrMsg
				, oSkuNew
				, oJobId
				, oShopOrderId
				, oFamily
				, oDatabaseId
				, oExpectedWeight
				, oServiceType
				, oTrackingNumber
			]

		sdc.tag.write(writePaths, writeValues, True)
		JobLoad_DbCall_FeederInfo(legNum, oShopOrderId, oSkuNew)
	except java.lang.Throwable, e:
		# Handle the java exception
		print "Job Load db Call - Get Job Part Info for Leg #" + leg + ". Java exception occurred:" + str(e)
		print "Cause: " + str(e.cause)
		myLogger.error(traceback.format_exc())
	except Exception, e:
		# Handle Python Exceptions
		print "Job Load db Call - Get Job Part Info for Leg #" + leg + ". Python exception occurred:" + str(e)
		print traceback.format_exc()
		myLogger.error(traceback.format_exc())
	finally:
		endTime = System.nanoTime()
		exeTime = 0.000001 * (endTime - startTime)
		#print "Load Part Info - Leg #{}, JobID:{}, {:.1f}ms.".format(legNum, oJobId, exeTime)
		
def JobLoad_DbCall_FeederInfo(legNum, shopOrderId, sku):
	startTime = System.nanoTime()
	myLogger = system.util.getLogger("myLogger")
	try:
		leg = str(legNum)

		readPrefix = "[default]Leg_{}/DB_Transactions/JobLoad_Inputs/".format(legNum)
		readPaths = [
			readPrefix + "U1_PartNumber"
			, readPrefix + "U2_PartNumber"
			, readPrefix + "U3_PartNumber"
			, readPrefix + "U4_PartNumber"
			, readPrefix + "U5_PartNumber"
			, readPrefix + "M1_PartNumber"
			, readPrefix + "M2_PartNumber"
			, readPrefix + "M3_PartNumber"
			, readPrefix + "M4_PartNumber"
		]		

		# Get the tag values needed for input parameters to the stored procedure
		readValues = sdc.tag.read(readPaths)
		
		if (shopOrderId == -1):
			writePrefix = "[default]Leg_{}/DB_Transactions/JobLoad_Outputs/".format(legNum)
			writePaths = [writePrefix + "spResponse2/NewId", writePrefix + "spResponse2/ErrorCode", writePrefix + "spResponse2/Message"]
			writeValues = [-1, -1, "Get Feeder info for Leg #" + leg + " exiting because sdcSP_GetJob failed."]
			print "Get Feeder info for Leg #" + leg + " exiting because sdcSP_GetJob failed."
			return

		pnUS1 = readValues[0]
		pnUS2 = readValues[1]
		pnUS3 = readValues[2]
		pnUS4 = readValues[3]
		pnUS5 = readValues[4]
		pnM1 = readValues[5]
		pnM2 = readValues[6]
		pnM3 = readValues[7]
		pnM4 = readValues[8]
			
		call = system.db.createSProcCall("sdcSP_GetSku_ActiveFeeders")

		call.registerOutParam(1, system.db.INTEGER) #NewID
		call.registerOutParam(2, system.db.INTEGER) #intErrorCode
		call.registerOutParam(3, system.db.VARCHAR) #CustomErrMsg
		call.registerOutParam(7, system.db.BIT) #U1_Active
		call.registerOutParam(8, system.db.INTEGER) #U1_MaterialID
		call.registerOutParam(9, system.db.FLOAT) #US1Weight
		call.registerOutParam(11, system.db.BIT) #U2_Active
		call.registerOutParam(12, system.db.INTEGER) #U2_MaterialID
		call.registerOutParam(13, system.db.FLOAT) #US2Weight
		call.registerOutParam(15, system.db.BIT) #U3_Active
		call.registerOutParam(16, system.db.INTEGER) #U3_MaterialID
		call.registerOutParam(17, system.db.FLOAT) #US3Weight
		call.registerOutParam(19, system.db.BIT) #U4_Active
		call.registerOutParam(20, system.db.INTEGER) #U4_MaterialID
		call.registerOutParam(21, system.db.FLOAT) #US4Weight
		call.registerOutParam(23, system.db.BIT) #U5_Active
		call.registerOutParam(24, system.db.INTEGER) #U5_MaterialID
		call.registerOutParam(25, system.db.FLOAT) #US5Weight
		call.registerOutParam(27, system.db.BIT) #M1_Active
		call.registerOutParam(29, system.db.BIT) #M2_Active
		call.registerOutParam(31, system.db.BIT) #M3_Active
		call.registerOutParam(33, system.db.BIT) #M4_Active
		call.registerOutParam(34, system.db.BIT) #EnvelopeRequired

		call.registerInParam(4, system.db.INTEGER, shopOrderId)
		call.registerInParam(5, system.db.NVARCHAR, sku)
		call.registerInParam(6, system.db.NVARCHAR, pnUS1)
		call.registerInParam(10, system.db.NVARCHAR, pnUS2)
		call.registerInParam(14, system.db.NVARCHAR, pnUS3)
		call.registerInParam(18, system.db.NVARCHAR, pnUS4)
		call.registerInParam(22, system.db.NVARCHAR, pnUS5)
		call.registerInParam(26, system.db.NVARCHAR, pnM1)
		call.registerInParam(28, system.db.NVARCHAR, pnM2)
		call.registerInParam(30, system.db.NVARCHAR, pnM3)
		call.registerInParam(32, system.db.NVARCHAR, pnM4)
		
		system.db.execSProcCall(call)
		#print "Get Feeder info for Leg #" + leg + ", SKU: " + sku + ". Stored procedure called."

		# Get the output parameters
		NewId = call.getOutParamValue(1)
		ErrorCode = call.getOutParamValue(2)
		ErrMsg = call.getOutParamValue(3)
		oActiveUS1 = call.getOutParamValue(7)
		oMaterialIdUS1 = call.getOutParamValue(8)
		oWeightUS1 = call.getOutParamValue(9)
		oActiveUS2 = call.getOutParamValue(11)
		oMaterialIdUS2 = call.getOutParamValue(12)
		oWeightUS2 = call.getOutParamValue(13)
		oActiveUS3 = call.getOutParamValue(15)
		oMaterialIdUS3 = call.getOutParamValue(16)
		oWeightUS3 = call.getOutParamValue(17)
		oActiveUS4 = call.getOutParamValue(19)
		oMaterialIdUS4 = call.getOutParamValue(20)
		oWeightUS4 = call.getOutParamValue(21)
		oActiveUS5 = call.getOutParamValue(23)
		oMaterialIdUS5 = call.getOutParamValue(24)
		oWeightUS5 = call.getOutParamValue(25)
		oActiveM1 = call.getOutParamValue(27)
		oActiveM2 = call.getOutParamValue(29)
		oActiveM3 = call.getOutParamValue(31)
		oActiveM4 = call.getOutParamValue(33)
		oEnvelopeRequired = call.getOutParamValue(34)

		writePrefix = "[default]Leg_{}/DB_Transactions/JobLoad_Outputs/".format(legNum)
		writePaths = [
			writePrefix + "spResponse2/NewId"
			, writePrefix + "spResponse2/ErrorCode"
			, writePrefix + "spResponse2/Message"
			, writePrefix + "US1"
			, writePrefix + "MaterialID_US1"
			, writePrefix + "US1Weight"
			, writePrefix + "US2"
			, writePrefix + "MaterialID_US2"
			, writePrefix + "US2Weight"
			, writePrefix + "US3"
			, writePrefix + "MaterialID_US3"
			, writePrefix + "US3Weight"
			, writePrefix + "US4"
			, writePrefix + "MaterialID_US4"
			, writePrefix + "US4Weight"
			, writePrefix + "US5"
			, writePrefix + "MaterialID_US5"
			, writePrefix + "US5Weight"
			, writePrefix + "Media1"
			, writePrefix + "Media2"
			, writePrefix + "Media3"
			, writePrefix + "Media4"
			, writePrefix + "EnvelopeRequired"
		]
		
		if (ErrorCode != 0):
			print "Job Load db Call - Get Feeder info for Leg #" + leg + ", SKU: " + sku + ". Stored procedure failed: " + ErrMsg
			writePaths = [
				writePrefix + "spResponse2/NewId"
				, writePrefix + "spResponse2/ErrorCode"
				, writePrefix + "spResponse2/Message"
			]
			writeValues = [
				NewId
				, ErrorCode
				, ErrMsg
			]
		else:
			#print "Get Feeder info for Leg #" + leg + ", SKU: " + sku + ". Stored procedure succeeded: " + ErrMsg
			#print "Get Feeder info for Leg #" + leg + ", SKU: " + sku + ". Unstackers Active: " + str(oActiveUS1) + ", " + str(oActiveUS2) + ", " + str(oActiveUS3) + ", " + str(oActiveUS4) + ", " + str(oActiveUS5)
			writeValues = [
				NewId
				, ErrorCode
				, ErrMsg
				, oActiveUS1
				, oMaterialIdUS1
				, oWeightUS1
				, oActiveUS2
				, oMaterialIdUS2
				, oWeightUS2
				, oActiveUS3
				, oMaterialIdUS3
				, oWeightUS3
				, oActiveUS4
				, oMaterialIdUS4
				, oWeightUS4
				, oActiveUS5
				, oMaterialIdUS5
				, oWeightUS5
				, oActiveM1
				, oActiveM2
				, oActiveM3
				, oActiveM4
				, oEnvelopeRequired
			]

		sdc.tag.write(writePaths, writeValues, True)
	except java.lang.Throwable, e:
		# Handle the java exception
		print "Job Load db Call - Get Feeder info for Leg #" + leg + ", SKU: " + sku + ". Java exception occurred:" + str(e)
		print "Cause: " + str(e.cause)
		myLogger.error(traceback.format_exc())
	except Exception, e:
		# Handle Python Exceptions
		print "Job Load db Call - Get Feeder info for Leg #" + leg + ", SKU: " + sku + ". Python exception occurred:" + str(e)
		print traceback.format_exc()
		myLogger.error(traceback.format_exc())
	finally:
		endTime = System.nanoTime()
		exeTime = 0.000001 * (endTime - startTime)
		#print "Job Load db Call - Get Feeder Info - Leg #{}, SKU:{}, {:.1f}ms.".format(legNum, sku, exeTime)
		
def JobLoad_WriteOutputs(legNum, stationName):
	startTime = System.nanoTime()
	myLogger = system.util.getLogger("myLogger")
	try:
		leg = str(legNum)

		readPrefix = "[default]Leg_{}/DB_Transactions/JobLoad_Outputs/".format(legNum)
		readPaths = [
			readPrefix + "SKU"
			, readPrefix + "JobID"
			, readPrefix + "ShopOrderID"
			, readPrefix + "Family"
			, readPrefix + "DatabaseID"
			, readPrefix + "ExpectedWeight"
			, readPrefix + "ServiceType"
			, readPrefix + "TrackingNumber"
			, readPrefix + "US1"
			, readPrefix + "MaterialID_US1"
			, readPrefix + "US1Weight"
			, readPrefix + "US2"
			, readPrefix + "MaterialID_US2"
			, readPrefix + "US2Weight"
			, readPrefix + "US3"
			, readPrefix + "MaterialID_US3"
			, readPrefix + "US3Weight"
			, readPrefix + "US4"
			, readPrefix + "MaterialID_US4"
			, readPrefix + "US4Weight"
			, readPrefix + "US5"
			, readPrefix + "MaterialID_US5"
			, readPrefix + "US5Weight"
			, readPrefix + "Media1"
			, readPrefix + "Media2"
			, readPrefix + "Media3"
			, readPrefix + "Media4"
			, readPrefix + "EnvelopeRequired"
		]		
		readValues = sdc.tag.read(readPaths)

		writePrefix = "[default]Leg_{}/StationTracking/{}/".format(legNum, stationName)
		writePaths = [
			"[default]Leg_{}/DB_Transactions/ShopOrderParameters/Active_SKU".format(legNum)
			, writePrefix + "From Database/SKU"
			, writePrefix + "From Database/JobID"
			, writePrefix + "From Database/ShopOrderID"
			, writePrefix + "From Database/Family"
			, writePrefix + "From Database/DatabaseID"
			, writePrefix + "From Database/ExpectedWeight"
			, writePrefix + "From Database/ServiceType"
			, writePrefix + "From Database/TrackingNumber"
			, writePrefix + "From Database/US1"
			, writePrefix + "To Database/MaterialID_US1"
			, writePrefix + "From Database/US1Weight"
			, writePrefix + "From Database/US2"
			, writePrefix + "To Database/MaterialID_US2"
			, writePrefix + "From Database/US2Weight"
			, writePrefix + "From Database/US3"
			, writePrefix + "To Database/MaterialID_US3"
			, writePrefix + "From Database/US3Weight"
			, writePrefix + "From Database/US4"
			, writePrefix + "To Database/MaterialID_US4"
			, writePrefix + "From Database/US4Weight"
			, writePrefix + "From Database/US5"
			, writePrefix + "To Database/MaterialID_US5"
			, writePrefix + "From Database/US5Weight"
			, writePrefix + "From Database/Media1"
			, writePrefix + "From Database/Media2"
			, writePrefix + "From Database/Media3"
			, writePrefix + "From Database/Media4"
			, writePrefix + "From Database/EnvelopeRequired"
			, writePrefix + "From Database/HandshakeFail"
			, writePrefix + "From Database/HandshakeSuccess"			
		]
		writeValues = [
			readValues[0]
			, readValues[0]
			, readValues[1]
			, readValues[2]
			, readValues[3]
			, readValues[4]
			, readValues[5]
			, readValues[6]
			, readValues[7]
			, readValues[8]
			, readValues[9]
			, readValues[10]
			, readValues[11]
			, readValues[12]
			, readValues[13]
			, readValues[14]
			, readValues[15]
			, readValues[16]
			, readValues[17]
			, readValues[18]
			, readValues[19]
			, readValues[20]
			, readValues[21]
			, readValues[22]
			, readValues[23]
			, readValues[24]
			, readValues[25]
			, readValues[26]
			, readValues[27]
			, False
			, True
		]
		
		sdc.tag.write(writePaths, writeValues, True)
	except java.lang.Throwable, e:
		# Handle the java exception
		print "Job Load db Call - Write Outputs for Leg #" + leg + ". Java exception occurred:" + str(e)
		print "Cause: " + str(e.cause)
		myLogger.error(traceback.format_exc())
	except Exception, e:
		# Handle Python Exceptions
		print "Job Load db Call - Write Outputs for Leg #" + leg + ". Python exception occurred:" + str(e)
		myLogger.error(traceback.format_exc())
	finally:
		endTime = System.nanoTime()
		exeTime = 0.000001 * (endTime - startTime)
		#print "Job Load db Call - Write Outputs for Leg #{}, JobID:{}, {:.1f}ms.".format(legNum, oJobId, exeTime)

def JobLoad_WriteOutputs_Failure(legNum, stationName):
	startTime = System.nanoTime()
	myLogger = system.util.getLogger("myLogger")
	try:
		leg = str(legNum)

		writePrefix = "[default]Leg_{}/StationTracking/{}/".format(legNum, stationName)
		writePaths = [
			writePrefix + "From Database/SKU"
			, writePrefix + "From Database/JobID"
			, writePrefix + "From Database/ShopOrderID"
			, writePrefix + "From Database/Family"
			, writePrefix + "From Database/DatabaseID"
			, writePrefix + "From Database/ExpectedWeight"
			, writePrefix + "From Database/ServiceType"
			, writePrefix + "From Database/TrackingNumber"
			, writePrefix + "From Database/US1"
			, writePrefix + "To Database/MaterialID_US1"
			, writePrefix + "From Database/US1Weight"
			, writePrefix + "From Database/US2"
			, writePrefix + "To Database/MaterialID_US2"
			, writePrefix + "From Database/US2Weight"
			, writePrefix + "From Database/US3"
			, writePrefix + "To Database/MaterialID_US3"
			, writePrefix + "From Database/US3Weight"
			, writePrefix + "From Database/US4"
			, writePrefix + "To Database/MaterialID_US4"
			, writePrefix + "From Database/US4Weight"
			, writePrefix + "From Database/US5"
			, writePrefix + "To Database/MaterialID_US5"
			, writePrefix + "From Database/US5Weight"
			, writePrefix + "From Database/Media1"
			, writePrefix + "From Database/Media2"
			, writePrefix + "From Database/Media3"
			, writePrefix + "From Database/Media4"
			, writePrefix + "From Database/EnvelopeRequired"
			, writePrefix + "From Database/HandshakeFail"
			, writePrefix + "From Database/HandshakeSuccess"			
		]
		writeValues = [
			""
			, 0
			, 0
			, 0
			, 0
			, 0.0
			, ""
			, ""
			, False
			, 0
			, 0.0
			, False
			, 0
			, 0.0
			, False
			, 0
			, 0.0
			, False
			, 0
			, 0.0
			, False
			, 0
			, 0.0
			, False
			, False
			, False
			, False
			, False
			, True
			, False
		]
		
		sdc.tag.write(writePaths, writeValues, True)
	except java.lang.Throwable, e:
		# Handle the java exception
		print "Job Load db Call - Write Outputs (Failure) for Leg #" + leg + ". Java exception occurred:" + str(e)
		print "Cause: " + str(e.cause)
		myLogger.error(traceback.format_exc())
	except Exception, e:
		# Handle Python Exceptions
		print "Job Load db Call - Write Outputs (Failure) for Leg #" + leg + ". Python exception occurred:" + str(e)
		myLogger.error(traceback.format_exc())
	finally:
		endTime = System.nanoTime()
		exeTime = 0.000001 * (endTime - startTime)
		#print "Job Load db Call - Write Outputs (Failure) for Leg #{}, JobID:{}, {:.1f}ms.".format(legNum, oJobId, exeTime)
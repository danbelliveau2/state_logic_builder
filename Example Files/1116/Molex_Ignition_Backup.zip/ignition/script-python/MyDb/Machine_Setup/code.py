from java.lang import System
import java.lang.Exception
import traceback

def Available_ShopOrdersRefresh(legNum):
	myLogger = system.util.getLogger("myLogger")
	try:
		leg = str(legNum)
		query = """
			SELECT DISTINCT ShopOrderID, PenType
			FROM vw_ShopOrders_Available
		"""		
		results = system.db.runPrepQuery(query)
		sdc.tag.write(["[default]Leg_" + leg + "/DB_Transactions/ShopOrderParameters/Available_ShopOrders"], results, True)
	except java.lang.Throwable, e:
		# Handle the java exception
		print "Available_ShopOrdersRefresh - Leg #" + leg + ". Java exception occurred:" + str(e)
		print "Cause: " + str(e.cause)
		myLogger.error(traceback.format_exc())
	except Exception, e:
		# Handle Python Exceptions
		print "Available_ShopOrdersRefresh - Leg #" + leg + ". Python exception occurred:" + str(e)
		myLogger.error(traceback.format_exc())

def Select_ShopOrder(event, legNum):
	startTime = System.nanoTime()
	myLogger = system.util.getLogger("myLogger")
	try:
		leg = str(legNum)
		if (len(event.data) == 0):
			print "Select_ShopOrder - Nothing selected. Exiting"
			return
		shopOrderId = event.data[0]["ShopOrderID"]
		sdc.tag.write(["[default]Leg_" + leg + "/DB_Transactions/ShopOrderParameters/Selected_ShopOrder"], [shopOrderId], True)		
		
		query = """
			SELECT DISTINCT
				Sku
				, QuantityRemaining AS Qty_Remaining
			FROM vw_SKU_Available
			WHERE ShopOrderID = ?
		"""
		results = system.db.runPrepQuery(query, [shopOrderId])
		sdc.tag.write(["[default]Leg_" + leg + "/DB_Transactions/ShopOrderParameters/Available_SKU"], results, True)

		query2 = """
			SELECT DISTINCT
				MaterialID
				, AltName
				, TotalParts As 'Total Parts'
				, BulkTraysNeeded As 'Bulk Trays'
				, MaterialType
			  FROM vw_Corp_ShopOrderBom
			WHERE
				ShopOrderID = ?
				AND LEN(AltName) > 1
			ORDER BY MaterialType DESC, MaterialID
		"""
		shopOrderBom = system.db.runPrepQuery(query2, [shopOrderId])
		sdc.tag.write(["[default]Leg_" + leg + "/DB_Transactions/ShopOrderParameters/Selected_ShopOrder_BOM"], shopOrderBom, True)
	except java.lang.Throwable, e:
		# Handle the java exception
		print "Select_ShopOrder - Leg #" + leg + ". Java exception occurred:" + str(e)
		print "Cause: " + str(e.cause)
		myLogger.error(traceback.format_exc())
	except Exception, e:
		# Handle Python Exceptions
		print "Select_ShopOrder - Leg #" + leg + ". Python exception occurred:" + str(e)
		myLogger.error(traceback.format_exc())
	finally:
		endTime = System.nanoTime()
		exeTime = 0.000001 * (endTime - startTime)
		#print 'Select ShopOrder took {:.2f}ms'.format(exeTime)

def Select_Sku(event, legNum):
	myLogger = system.util.getLogger("myLogger")
	try:
		leg = str(legNum)
		if (len(event.data) == 0):
			print __name__ + 'Nothing selected. Exiting'
			return
		sku = event.data[0]["Sku"]
		sdc.tag.write(["[default]Leg_" + leg + "/DB_Transactions/ShopOrderParameters/Selected_SKU"], [sku], True)
		
		readValues = sdc.tag.read(["[default]Leg_" + leg + "/DB_Transactions/ShopOrderParameters/Selected_ShopOrder"])
		selectedShopOrderId = readValues[0]
		
		query = """
			SELECT DISTINCT TOP 20
				COUNT(JA.JobID) As Count
				, JA.ServiceType
			FROM vw_Job_Available JA
			WHERE
				JA.ShopOrderID = ?
				AND JA.Sku = ?
			GROUP BY JA.ServiceType
		"""
		results = system.db.runPrepQuery(query, [selectedShopOrderId, sku])
		sdc.tag.write(["[default]Leg_" + leg + "/DB_Transactions/ShopOrderParameters/Selected_SKU_ServiceTypes"], [results], True)
		
		query = """
			SELECT DISTINCT
				OB.MaterialID
				, CASE
					when OT.PenType = '2X' AND MM.MaterialType = 'ZAIP' then MM.Pica
					when OT.PenType = 'Ziggy' AND MM.MaterialType = 'ZAIP' then MM.Pica
					when OT.PenType = 'Nesta' AND MM.MaterialType = 'ZAIP' then MM.MaterialCode
					when MM.MaterialType = 'ZAIM' then MM.MaterialCode
				END AS PartNumber
				, CASE
					when MM.MaterialType = 'ZAIP' then MM.AltName
					when MM.MaterialType = 'ZAIM' then MM.Description
				END AS Description
				, MM.AltName
				, MM.MaterialType
				, MM.Color
			  FROM OrderTable OT
				INNER JOIN OrderBom OB
					ON OT.JobID = OB.JobID AND OT.ShopOrderID = OB.ShopOrderID
				INNER JOIN MaterialMaster MM
					ON OB.MaterialID = MM.MaterialID
			WHERE
				OT.ShopOrderID = ?
				AND OT.Sku = ?
			ORDER BY MM.MaterialType DESC, MM.Color
		"""
		results = system.db.runPrepQuery(query, [selectedShopOrderId, sku])
		sdc.tag.write(["[default]Leg_" + leg + "/DB_Transactions/ShopOrderParameters/Selected_SKU_BOM"], [results], True)
	except java.lang.Throwable, e:
		# Handle the java exception
		print "Select_Sku - Leg #" + leg + ". Java exception occurred:" + str(e)
		print "Cause: " + str(e.cause)
		myLogger.error(traceback.format_exc())
	except Exception, e:
		# Handle Python Exceptions
		print "Select_Sku - Leg #" + leg + ". Python exception occurred:" + str(e)
		myLogger.error(traceback.format_exc())

def MakeSelectedSkuActive(event, legNum):
	myLogger = system.util.getLogger("myLogger")
	try:
		leg = str(legNum)
		readPaths = [
			"[default]Leg_" + leg + "/DB_Transactions/ShopOrderParameters/Selected_ShopOrder"
			, "[default]Leg_" + leg + "/DB_Transactions/ShopOrderParameters/Selected_SKU"
		]
		readValues = sdc.tag.read(readPaths)
		selectedShopOrderId = readValues[0]
		selectedSku = readValues[1]
		writeTags = [
			"[default]Leg_" + leg + "/DB_Transactions/ShopOrderParameters/Active_ShopOrderID"
			, "[default]Leg_" + leg + "/DB_Transactions/ShopOrderParameters/Active_SKU"
		]
		print "Dave's database testing view, Leg #" + leg + " selected ShopOrder: ", str(selectedShopOrderId), ", SKU: ", selectedSku
		writeValues = [
			selectedShopOrderId
			, selectedSku
		]
		sdc.tag.write(writeTags, writeValues, True)
	except java.lang.Throwable, e:
		# Handle the java exception
		print "MakeSelectedSkuActive - Leg #" + leg + ". Java exception occurred:" + str(e)
		print "Cause: " + str(e.cause)
		myLogger.error(traceback.format_exc())
	except Exception, e:
		# Handle Python Exceptions
		print "MakeSelectedSkuActive - Leg #" + leg + ". Python exception occurred:" + str(e)
		myLogger.error(traceback.format_exc())
		
def ClearAllData(event, legNum):
	myLogger = system.util.getLogger("myLogger")
	try:
		leg = str(legNum)
		call = system.db.createSProcCall("sdcSP_ClearAllData")

		call.registerOutParam(1, system.db.INTEGER)
		call.registerOutParam(2, system.db.INTEGER)
		call.registerOutParam(3, system.db.VARCHAR)

		call.registerInParam(4, system.db.TINYINT, legNum)
		
		system.db.execSProcCall(call)
		  
		# Get the output parameters
		NewId = call.getOutParamValue(1)
		ErrorCode = call.getOutParamValue(2)
		ErrMsg = call.getOutParamValue(3)

		if (ErrorCode != 0):
			print "Clear All Data Leg #" + leg + " stored procedure failed: " + ErrMsg
		else:
			print "Clear All Data Leg #" + leg + " stored procedure succeeded: " + ErrMsg
	except java.lang.Throwable, e:
		# Handle the java exception
		print "Clear All Data - Leg #" + leg + ". Java exception occurred:" + str(e)
		print "Cause: " + str(e.cause)
		myLogger.error(traceback.format_exc())
	except Exception, e:
		# Handle Python Exceptions
		print "Clear All Data - Leg #" + leg + ". Python exception occurred:" + str(e)
		myLogger.error(traceback.format_exc())

def DeferActiveShopOrder(event, legNum):
	myLogger = system.util.getLogger("myLogger")
	try:
		leg = str(legNum)
		readPaths = ["[default]Leg_" + leg + "/DB_Transactions/ShopOrderParameters/Active_ShopOrderID"]
		readValues = sdc.tag.read(readPaths)
		shopOrderId = readValues[0]
		
		call = system.db.createSProcCall("sdcSP_DeferActiveShopOrder")

		call.registerOutParam(1, system.db.INTEGER)
		call.registerOutParam(2, system.db.INTEGER)
		call.registerOutParam(3, system.db.VARCHAR)

		call.registerInParam(4, system.db.INTEGER, shopOrderId)

		system.db.execSProcCall(call)
		  
		# Get the output parameters
		NewId = call.getOutParamValue(1)
		ErrorCode = call.getOutParamValue(2)
		ErrMsg = call.getOutParamValue(3)

		if (ErrorCode != 0):
			print "Defer Remaining ShopOrder (" + str(shopOrderId) + "). Stored procedure failed: " + ErrMsg
		else:
			print "Defer Remaining ShopOrder (" + str(shopOrderId) + "). Stored procedure succeeded: " + ErrMsg
	except java.lang.Throwable, e:
		# Handle the java exception
		print "Defer Remaining ShopOrder (" + str(shopOrderId) + "). Java exception occurred:" + str(e)
		print "Cause: " + str(e.cause)
		myLogger.error(traceback.format_exc())
	except Exception, e:
		# Handle Python Exceptions
		print "Defer Remaining ShopOrder (" + str(shopOrderId) + "). Python exception occurred:" + str(e)
		myLogger.error(traceback.format_exc())
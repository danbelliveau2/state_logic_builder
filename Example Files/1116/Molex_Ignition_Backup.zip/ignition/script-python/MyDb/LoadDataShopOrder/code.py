from java.lang import System
import java.lang.Exception
import traceback

def ShopOrderChange(legNum, shopOrderId):
	myLogger = system.util.getLogger("myLogger")
	try:
		# Initialize the writeValues. If an exception occurs these may be written to the write tags.
		writeValues = ["Shop Order Change for Leg #{}, new Shop Order:{}. Script failed.".format(legNum,shopOrderId),-1]
		
		pathPrefix = "[default]Leg_{}/DB_Transactions/".format(legNum)
		
		writePaths = [pathPrefix + "AlarmDetails_ShopOrderChange"]
		writePaths.extend([pathPrefix + "ShopOrderParameters/Active_ShopOrderID"])

		if (shopOrderId == 0):
			writeValues = ["Shop Order Change for Leg #{}, zero Shop Order.".format(legNum),0]
			return
			
		call = system.db.createSProcCall("sdcSP_ShopOrderChange")

		# Register the output parameters
		call.registerOutParam(1, system.db.INTEGER) #NewId
		call.registerOutParam(2, system.db.INTEGER) #intErrorCode
		call.registerOutParam(3, system.db.VARCHAR) #CustomErrMsg

		# Register the input parameters
		call.registerInParam(4, system.db.INTEGER, ActiveShopOrderId)
		
		system.db.execSProcCall(call)
		  
		# Get the output parameters results
		NewId = call.getOutParamValue(1)
		ErrorCode = call.getOutParamValue(2)
		ErrMsg = call.getOutParamValue(3)
		
		if (ErrorCode != 0):
			msg =  "Shop Order Change for Leg #{}, new Shop Order:{}. Stored procedure failed: {}.".format(legNum, shopOrderId, ErrMsg)
			print msg
			writeValues[0] = msg
		else:
			writeValues = [ErrMsg,shopOrderId]
	except java.lang.Throwable, e:
		# Handle the java exception
		print "Shop Order Change for Leg #{}, new Shop Order:{}. Java exception occurred: {}".format(legNum, shopOrderId, e)
		print "Cause: {}".format(e.cause)
		myLogger.error(traceback.format_exc())
	except Exception, e:
		# Handle Python Exceptions
		print "Shop Order Change for Leg #{}, new Shop Order:{}. Python exception occurred: {}.".format(legNum, shopOrderId, e)
		myLogger.error(traceback.format_exc())
	finally:
		sdc.tag.write(writePaths, writeValues, True)
		print "Shop Order Change for Leg #{}, new Shop Order:{}. Function completed successfully.".format(legNum, shopOrderId)
		
def GetPenAssignments(legNum, ActiveShopOrderId):
	myLogger = system.util.getLogger("myLogger")
	try:
		# Initialize the writeValues. If an exception occurs these may be written to the write tags.
		msg = "Get ShopOrder ({}) Pen Assignments for Leg #{} script failed.".format(ActiveShopOrderId, legNum)
		retOutParams = ["","","",0,0,0,False,""] * 5
		writeValues = [-1,-1,msg,msg,""] + retOutParams

		pathPrefix = "[default]Leg_{}/DB_Transactions/Components_Current/".format(legNum)
		
		writePaths = [pathPrefix + "spResponse/NewId", pathPrefix + "spResponse/ErrorCode", pathPrefix + "spResponse/Message"]
		writePaths.extend(["[default]Leg_{}/DB_Transactions/AlarmDetails_ShopOrderChange".format(legNum)])
		writePaths.extend([pathPrefix + "PenType"])
		for i in range(1, 6, 1):
			writePaths.extend([
			"{}U{}_PartNumber".format(pathPrefix, i)
			, "{}U{}_BulkTray_PartNumber".format(pathPrefix, i)
			, "{}U{}_Color".format(pathPrefix, i)
			, "{}U{}_Quantity".format(pathPrefix, i)
			, "{}U{}_Family".format(pathPrefix, i)
			, "{}U{}_ShelfLifeDays".format(pathPrefix, i)
			, "{}U{}_IsBlack".format(pathPrefix, i)
			, "{}U{}_AltName".format(pathPrefix, i)
		])

		call = system.db.createSProcCall("sdcSP_GetPenAssignments")

		# Register the output parameters
		call.registerOutParam(1, system.db.INTEGER) #NewId
		call.registerOutParam(2, system.db.INTEGER) #intErrorCode
		call.registerOutParam(3, system.db.VARCHAR) #CustomErrMsg
		call.registerOutParam(5, system.db.NVARCHAR) #PenType
		for i in range(6, 46, 8):
			call.registerOutParam(i, system.db.NVARCHAR) #Ux_PartNumber
			call.registerOutParam(i+1, system.db.NVARCHAR) #Ux_MaterialCode
			call.registerOutParam(i+2, system.db.NVARCHAR) #Ux_Color
			call.registerOutParam(i+3, system.db.INTEGER) #Ux_Quantity
			call.registerOutParam(i+4, system.db.INTEGER) #Ux_Family
			call.registerOutParam(i+5, system.db.INTEGER) #Ux_ShelfLifeDays
			call.registerOutParam(i+6, system.db.BIT) #Ux_IsBlack
			call.registerOutParam(i+7, system.db.NVARCHAR) #Ux_AltName

		# Register the input parameters
		call.registerInParam(4, system.db.INTEGER, ActiveShopOrderId)
		
		system.db.execSProcCall(call)
		  
		# Get the output parameters results
		NewId = call.getOutParamValue(1)
		ErrorCode = call.getOutParamValue(2)
		ErrMsg = call.getOutParamValue(3)
		PenType = call.getOutParamValue(5)
		retOutParams = [call.getOutParamValue(i) for i in range(6, 46, 1)]
		
		if (ErrorCode != 0):
			msg = "Get ShopOrder ({}) Pen Assignments for Leg #{}. Stored procedure failed: {}.".format(ActiveShopOrderId, legNum, ErrMsg)
			print msg
			writeValues[0] = NewId
			writeValues[1] = ErrorCode
			writeValues[2] = ErrMsg
			writeValues[3] = msg
		else:
			writeValues = [NewId,ErrorCode,ErrMsg,ErrMsg,PenType] + retOutParams
	except java.lang.Throwable, e:
		# Handle the java exception
		print "Get ShopOrder ({}) Pen Assignments for Leg #{}. Java exception occurred: {}.".format(ActiveShopOrderId, legNum, e)
		print "Cause: " + str(e.cause)
		myLogger.error(traceback.format_exc())
	except Exception, e:
		# Handle Python Exceptions
		print "Get ShopOrder ({}) Pen Assignments for Leg #{}. Python exception occurred: {}.".format(ActiveShopOrderId, legNum, e)
		myLogger.error(traceback.format_exc())
	finally:
		#print writePaths
		#print writeValues
		sdc.tag.write(writePaths, writeValues, True)
		#print "Get ShopOrder ({}) Start Pen Assignments for Leg #{} function completed.".format(ActiveShopOrderId, legNum)

def GetMediaAssignments(legNum, ActiveShopOrderId):
	myLogger = system.util.getLogger("myLogger")
	try:
		# Initialize the writeValues. If an exception occurs these may be written to the write tags.
		msg = "Get ShopOrder ({}) Media Assignments for Leg #{} script failed.".format(ActiveShopOrderId, legNum)
		retOutParams = ["",0,""] * 4
		writeValues = [-1,-1,msg,msg] + retOutParams		

		pathPrefix = "[default]Leg_{}/DB_Transactions/Components_Current/".format(legNum)
		
		writePaths = [pathPrefix + "spResponse/NewId", pathPrefix + "spResponse/ErrorCode", pathPrefix + "spResponse/Message"]
		writePaths.extend(["[default]Leg_{}/DB_Transactions/AlarmDetails_ShopOrderChange".format(legNum)])
		for i in range(1, 5, 1):
			writePaths.extend([
			"{}M{}_PartNumber".format(pathPrefix, i)
			, "{}M{}_Quantity".format(pathPrefix, i)
			, "{}M{}_AltName".format(pathPrefix, i)
		])

		call = system.db.createSProcCall("sdcSP_GetMediaAssignments")

		# Register the output parameters
		call.registerOutParam(1, system.db.INTEGER) #NewId
		call.registerOutParam(2, system.db.INTEGER) #intErrorCode
		call.registerOutParam(3, system.db.VARCHAR) #CustomErrMsg
		for i in range(5, 17, 3):
			call.registerOutParam(i, system.db.NVARCHAR) #Mx_PartNumber
			call.registerOutParam(i+1, system.db.INTEGER) #Mx_Quantity
			call.registerOutParam(i+2, system.db.NVARCHAR) #Mx_AltName

		# Register the input parameters
		call.registerInParam(4, system.db.INTEGER, ActiveShopOrderId)
		
		system.db.execSProcCall(call)
		  
		# Get the output parameters results
		NewId = call.getOutParamValue(1)
		ErrorCode = call.getOutParamValue(2)
		ErrMsg = call.getOutParamValue(3)
		retOutParams = [call.getOutParamValue(i) for i in range(5, 17, 1)]
		
		if (ErrorCode != 0):
			msg = "Get ShopOrder ({}) Media Assignments for Leg #{}. Stored procedure failed: {}.".format(ActiveShopOrderId, legNum, ErrMsg)
			print msg
			writeValues[0] = NewId
			writeValues[1] = ErrorCode
			writeValues[2] = ErrMsg
			writeValues[3] = msg
		else:
			writeValues = [NewId,ErrorCode,ErrMsg,ErrMsg] + retOutParams
	except java.lang.Throwable, e:
		# Handle the java exception
		print "Get ShopOrder ({}) Media Assignments for Leg #{}. Java exception occurred: {}.".format(ActiveShopOrderId, legNum, e)
		print "Cause: " + str(e.cause)
		myLogger.error(traceback.format_exc())
	except Exception, e:
		# Handle Python Exceptions
		print "Get ShopOrder ({}) Media Assignments for Leg #{}. Python exception occurred: {}.".format(ActiveShopOrderId, legNum, e)
		myLogger.error(traceback.format_exc())
	finally:
		sdc.tag.write(writePaths, writeValues, True)
		#print "Get ShopOrder ({}}) Media Assignments for Leg #{} function completed.".format(ActiveShopOrderId, legNum)

def GetQuantity(legNum, ActiveShopOrderId):
	myLogger = system.util.getLogger("myLogger")
	try:
		query = """
			SELECT COUNT(JobID) AS ShopOrder_Qty
			FROM OrderTable
			WHERE ShopOrderID = ?
		"""
		results = system.db.runPrepQuery(query, [ActiveShopOrderId])
		
		sdc.tag.write(["[default]Leg_{}/DB_Transactions/ShopOrderParameters/ShopOrder_Qty".format(legNum)], results[0], True)
	except java.lang.Throwable, e:
		# Handle the java exception
		print "Get ShopOrder ({}) Quantity for Leg #{}. Java exception occurred: {}.".format(ActiveShopOrderId, legNum, e)
		print "Cause: {}".format(e.cause)
		myLogger.error(traceback.format_exc())
	except Exception, e:
		# Handle Python Exceptions
		print "Get ShopOrder ({}) Quantity for Leg #{}. Python exception occurred: {}.".format(ActiveShopOrderId, legNum, e)
		myLogger.error(traceback.format_exc())
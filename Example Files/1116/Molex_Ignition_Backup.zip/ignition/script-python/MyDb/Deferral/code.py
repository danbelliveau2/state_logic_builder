from java.lang import System
import java.lang.Exception
import traceback

def DeferJob(event, legNum, nestNum):
	startTime = System.nanoTime()
	myLogger = system.util.getLogger("myLogger")
	try:
		opcPrefix = "ns=1;s=[PLC1058]L{}_StationStatus[{}].PartInfo.FromDatabase.".format(legNum,nestNum)
		
		opcTagPaths = [
			opcPrefix + "ShopOrderID"			
			, opcPrefix + "JobID"
		]
		opcValues = sdc.tag.read(opcTagPaths, True)

		ShopOrderId = opcValues[0]
		JobId = opcValues[1]
		
		if (ShopOrderId == 0 or JobId == 0):
			msg = "Defer Job - ShopOrderID:{}, JobID:{}. Can't run if either are zero.".format(ShopOrderId, JobId)
			print msg
			return

		call = system.db.createSProcCall("sdcSP_DeferJob")
		
		call.registerOutParam(1, system.db.INTEGER) #NewID
		call.registerOutParam(2, system.db.INTEGER) #intErrorCode
		call.registerOutParam(3, system.db.VARCHAR) #CustomErrMsg
		
		call.registerInParam(4, system.db.INTEGER, ShopOrderId)
		call.registerInParam(5, system.db.INTEGER, JobId)
		
		system.db.execSProcCall(call)
		  
		# Get the output parameters
		NewID = call.getOutParamValue(1)
		ErrorCode = call.getOutParamValue(2)
		ErrMsg = call.getOutParamValue(3)

		if (ErrorCode != 0):
			msg = "Defer Job - ShopOrderID:{}, JobID:{} - stored procedure failed: {}".format(ShopOrderId, JobId, ErrMsg)
			print msg
	except java.lang.Throwable, e:
		# Handle the java exception
		print "Defer Job. Java exception occurred:" + str(e)
		print "Cause: " + str(e.cause)
		myLogger.error(traceback.format_exc())
	except Exception, e:
		# Handle Python Exceptions
		print "Defer Job. Python exception occurred:" + str(e)
		myLogger.error(traceback.format_exc())
	finally:
		endTime = System.nanoTime()
		exeTime = 0.000001 * (endTime - startTime)
		print "Defer Job - Leg:{}, Nest:{}, ShopOrderID:{}, JobID:{}. {:.1f}ms.".format(legNum, nestNum, ShopOrderId, JobId, exeTime)
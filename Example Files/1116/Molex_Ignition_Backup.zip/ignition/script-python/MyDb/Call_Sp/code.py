# This example is for a stored procedure with input parameter, output parameters and returns a row of values
import java.lang.Exception
import traceback

def TestSp():
	myLogger = system.util.getLogger("myLogger")
	try:
		pathPrefix = "[default]Leg_1/StationTracking/WeighStationStatus/"
		opcPrefix = "ns=1;s=[PLC1058]L" + leg + "_WeighStationStatus.PartInfo."
		inParamTagPaths = [
			pathPrefix + "From Database/ShopOrderID"
			, pathPrefix + "From Database/JobID"
			, pathPrefix + "To Database/ToteBarcode_2"
		]
		opcParamTagPaths = [
			opcPrefix + "FromDatabase.ShopOrderID"
			, opcPrefix + "FromDatabase.JobID"
			, opcPrefix + "ToDatabase.ToteBarcode[1]"
		]		
		# Get the tag values needed for input parameters to the stored procedure
		#readValues = [x.value for x in system.tag.readBlocking(inParamTagPaths)]
		readValues = [x.value for x in system.opc.readValues('Ignition OPC UA Server', opcTagPaths)]
		
		ShopOrderId = readValues[0]
		JobId = readValues[1]
		BulkTrayTraceability_1 = readValues[2]
		
		call = system.db.createSProcCall("sdcSP_GetPenTest")
		
		call.registerOutParam("NewID", system.db.INTEGER)
		call.registerOutParam("intErrorCode", system.db.INTEGER)
		call.registerOutParam("CustomErrMsg", system.db.VARCHAR)

		#pturmel: There are known issues with some JDBC drivers and named parameters.
		#Use 1, 2, and 3 in your parameter registration instead of the names.
		
		#call.registerInParam("pShopOrderId", system.db.INTEGER, ShopOrderId)
		#call.registerInParam("pJobId", system.db.INTEGER, JobId)
		#call.registerInParam("pBulkTrayTraceability_1", system.db.NVARCHAR, BulkTrayTraceability_1)

		#call.registerOutParam(1, system.db.INTEGER)
		#call.registerOutParam(2, system.db.INTEGER)
		#call.registerOutParam(3, system.db.VARCHAR)

		call.registerInParam(4, system.db.INTEGER, ShopOrderId)
		call.registerInParam(5, system.db.INTEGER, JobId)
		call.registerInParam(6, system.db.NVARCHAR, BulkTrayTraceability_1)

		print "Job ID:" + str(JobId) + ", ShopOrder ID:" + str(ShopOrderId) + ", BulkTray:" + str(BulkTrayTraceability_1)
		#print call

		system.db.execSProcCall(call)
		  
		# Print the result to the console
		print call.getOutParamValue("NewID")
		print call.getOutParamValue("intErrorCode")
		print call.getOutParamValue("CustomErrMsg")
		
		# Return a result set
		results = call.getResultSet()
		print results
		
		for row in range(results.rowCount):
			for col in range(results.columnCount):
				print results.getValueAt(row, col)
		
		print "Num result rows: " + str(call.getUpdateCount())
	except java.lang.Throwable, e:
		# Handle the java exception
		print "Java exception occurred:" + str(e)
		myLogger.error(traceback.format_exc())
	except Exception, e:
	    # Handle general errors
		print "A general exception occurred:" + str(e)
		myLogger.error(traceback.format_exc())
	finally:
	    print "TestSp Function completed"

def readTest():
	myLogger = system.util.getLogger("myLogger")
	try:
		igPrefix = "[default]Leg_1/DB_Transactions/ShopOrderParameters/"
		opcPrefix = "ns=1;s=[PLC1058]L1_ComponentStatus.Current."
		igPaths = [
			igPrefix + "Active_ShopOrderID"
			, igPrefix + "Active_SKUs"
		]
		opcPaths = [
			opcPrefix + "US1.PartNumber"
			, opcPrefix + "US1.Quantity"
			, opcPrefix + "Media4.PartNumber"
		]
		igValues = sdc.tag.read(igPaths, False)
		if igValues:
			print "Ignition value 0: " + str(igValues[0])
			print "Ignition value 1: " + str(igValues[1])
		
		opcValues = sdc.tag.read(opcPaths, True)
		if opcValues:
			print "OPC value 0: " + str(opcValues[0])
			print "OPC value 1: " + str(opcValues[1])
			print "OPC value 1: " + str(opcValues[2])
	except java.lang.Throwable, e:
		# Handle the java exception
		print "Java exception occurred:" + str(e)
		myLogger.error(traceback.format_exc())
	except Exception, e:
	    # Handle general errors
		print "A general exception occurred:" + str(e)
		myLogger.error(traceback.format_exc())
	finally:
	    print "readTest Function completed"
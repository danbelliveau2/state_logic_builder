from java.lang import System
import java.lang.Exception
import traceback

def GetUnloadServiceType(stationNum):
	"""Scan the Tracking number at start of the Unload conveyor,
	get the associated ShopOrderID, JobID, and ServiceType from the database."""	
	myLogger = system.util.getLogger("myLogger")
	try:
		sta = str(stationNum)
		# writeValues default/failed handshake is "success" because writing a 0 to ServiceType
		# ensures the box goes to the reject gaylords.
		# Not writing True to HandshakeFail ensures the line keeps running.
		writeValues = [-1,-1,"Get Unload Info for Station #" + sta + " script failed.",0,0,0,False,True]
		pathPrefix = "[default]Unload/StationTracking/" + sta + "/"
		
		opcPrefix = "ns=1;s=[PLC1058]Unload_StationStatus[" + sta + "].PartInfo."
		opcTagPaths = [
			opcPrefix + "ToDatabase.TrackingNumber"
		]
		# Get the tag values needed for input parameters to the stored procedure
		opcValues = sdc.tag.read(opcTagPaths,True)
		
		writePaths = [
			pathPrefix + "spResponse/NewId"
			, pathPrefix + "spResponse/ErrorCode"
			, pathPrefix + "spResponse/Message"
			, pathPrefix + "ShopOrderID"
			, pathPrefix + "JobID"
			, pathPrefix + "ServiceType"
			, pathPrefix + "HandshakeFail"
			, pathPrefix + "HandshakeSuccess"		
		]

		trackingNumber = opcValues[0]

		call = system.db.createSProcCall("sdcSP_JobUnloadGetServiceType")

		call.registerOutParam(1, system.db.INTEGER) #NewID
		call.registerOutParam(2, system.db.INTEGER) #intErrorCode
		call.registerOutParam(3, system.db.VARCHAR) #CustomErrMsg
		call.registerOutParam(5, system.db.INTEGER) #ShopOrderId
		call.registerOutParam(6, system.db.INTEGER) #JobId
		call.registerOutParam(7, system.db.INTEGER) #ServiceType

		call.registerInParam(4, system.db.NVARCHAR, trackingNumber)
		
		system.db.execSProcCall(call)
		  
		# Get the output parameters
		NewId = call.getOutParamValue(1)
		ErrorCode = call.getOutParamValue(2)
		ErrMsg = call.getOutParamValue(3)
		shopOrderId = call.getOutParamValue(5)
		jobId = call.getOutParamValue(6)
		serviceType = call.getOutParamValue(7)

		if (ErrorCode != 0):
			#print "Get Unload Service Type for Station #" + sta + " stored procedure failed: " + ErrMsg
			writeValues[0] = NewId
			writeValues[1] = ErrorCode
			writeValues[2] = ErrMsg
		else:
			#print "Get Unload Service Type for Station #" + sta + " stored procedure succeeded: " + ErrMsg
			writeValues = [
				NewId
				, ErrorCode
				, ErrMsg
				, shopOrderId
				, jobId
				, serviceType
				, False
				, True
			]
	except java.lang.Throwable, e:
		# Handle the java exception
		print "Get Unload Service Type for Station #" + sta + ". Java exception occurred:" + str(e)
		print "Cause: " + str(e.cause)
		myLogger.error(traceback.format_exc())
	except Exception, e:
		# Handle Python Exceptions
		print "Get Unload Service Type for Station #" + sta + ". Python exception occurred:" + str(e)
		myLogger.error(traceback.format_exc())
	finally:
		sdc.tag.write(writePaths, writeValues, True)
		#print "Get Unload Service Type for Station #" + sta + " function completed."

def UnloadIntoGaylord():
	startTime = System.nanoTime()
	myLogger = system.util.getLogger("myLogger")
	try:
		pathPrefix = "[default]Unload/Logging/"
		opcPrefix = "ns=1;s=[PLC1058]Program:Unload_Logging."
		
		writePaths = [
			pathPrefix + "spResponse/NewId"
			, pathPrefix + "spResponse/ErrorCode"
			, pathPrefix + "spResponse/Message"		
			, pathPrefix + "Handshake/FailureResult"
			, pathPrefix + "Handshake/SuccessResult"
			, pathPrefix + "Handshake/Trigger"
			, pathPrefix + "Handshake/IgnitionBusy"			
		]
		writeValues = [-1,-1,"Unload into Gaylor script failed.",True,False,False,False]
		
		opcTagPaths = [
			opcPrefix + "Handshake.TransactionID"
			, opcPrefix + "Data.ShopOrderID"			
			, opcPrefix + "Data.JobID"
			, opcPrefix + "Data.GaylordID"
		]
		sdc.tag.write([pathPrefix + "Handshake/IgnitionBusy"], [True], False)

		opcValues = sdc.tag.read(opcTagPaths, True)

		TransactionId = opcValues[0]
		ShopOrderId = opcValues[1]
		JobId = opcValues[2]
		GaylordId = opcValues[3]
		#print "Unload Into Gaylord - trans ID:" + str(TransactionId) + ", job ID:" + str(JobId)
		
		newTransactionId = (TransactionId % 10000) + 1
		sdc.tag.write([pathPrefix + "Handshake/TransactionID"], [newTransactionId], True)

		call = system.db.createSProcCall("sdcSP_JobGaylord")
		
		call.registerOutParam(1, system.db.INTEGER) #NewID
		call.registerOutParam(2, system.db.INTEGER) #intErrorCode
		call.registerOutParam(3, system.db.VARCHAR) #CustomErrMsg
		
		call.registerInParam(4, system.db.INTEGER, ShopOrderId)
		call.registerInParam(5, system.db.INTEGER, JobId)
		call.registerInParam(6, system.db.INTEGER, GaylordId)		
		
		system.db.execSProcCall(call)
		  
		# Get the output parameters
		NewID = call.getOutParamValue(1)
		ErrorCode = call.getOutParamValue(2)
		ErrMsg = call.getOutParamValue(3)

		if (ErrorCode != 0):
			print "Unload Into Gaylord (trans ID:" + str(TransactionId) + ") stored procedure failed: ", ErrMsg
			#writeValues = [NewID,ErrorCode,ErrMsg,True,False,False,False]
			# Writing a Success because the part has already been pushed into the Gaylord. D.E.S. 2024-11-25 
			writeValues = [NewID,ErrorCode,ErrMsg,False,True,False,False]
		else:
			writeValues = [NewID,ErrorCode,ErrMsg,False,True,False,False]
	except java.lang.Throwable, e:
		# Handle the java exception
		print "Unload Into Gaylord. Java exception occurred:" + str(e)
		print "Cause: " + str(e.cause)
		myLogger.error(traceback.format_exc())
	except Exception, e:
		# Handle Python Exceptions
		print "Unload Into Gaylord. Python exception occurred:" + str(e)
		myLogger.error(traceback.format_exc())
	finally:
		sdc.tag.write(writePaths, writeValues, True)
		endTime = System.nanoTime()
		exeTime = 0.000001 * (endTime - startTime)
		#print "Unload int0 Gaylord - JobID:{}, GaylordID:{}. {:.1f}ms.".format(JobId, GaylordId, exeTime)
		#print "Unload Into Gaylord function completed"

def UnloadOrRejectFromInfeed(legNum):
	startTime = System.nanoTime()
	myLogger = system.util.getLogger("myLogger")
	try:
		leg = str(legNum)
		pathPrefix = "[default]Leg_" + leg + "/InfeedUnloadLogging/"
		opcPrefix = "[PLC1058]Program:L" + leg + "_Unload_Logging."
		sdc.tag.write([pathPrefix + "Handshake/IgnitionBusy"], [True], False)
		
		writePaths = [
			pathPrefix + "spResponse/NewId"
			, pathPrefix + "spResponse/ErrorCode"
			, pathPrefix + "spResponse/Message"		
			, pathPrefix + "Handshake/FailureResult"
			, pathPrefix + "Handshake/SuccessResult"
			, pathPrefix + "Handshake/Trigger"
			, pathPrefix + "Handshake/IgnitionBusy"			
		]
		writeValues = [-1,-1,"Unload from Infeed Leg #" + leg + " script failed.",True,False,False,False]

		opcTagPaths = [
			opcPrefix + "Handshake.TransactionID"
			, opcPrefix + "Data.PartInfo.FromDatabase.ShopOrderID"
			, opcPrefix + "Data.PartInfo.FromDatabase.JobID"
			, opcPrefix + "Data.HeadNumber"
			, opcPrefix + "Data.PartInfo.ToDatabase.BoxWeight"
			, opcPrefix + "Data.PartInfo.ToDatabase.ToteBarcode[0]"
			, opcPrefix + "Data.PartInfo.ToDatabase.ToteBarcode[1]"
			, opcPrefix + "Data.PartInfo.ToDatabase.ToteBarcode[2]"
			, opcPrefix + "Data.PartInfo.ToDatabase.ToteBarcode[3]"
			, opcPrefix + "Data.PartInfo.ToDatabase.ToteBarcode[4]"			
			, opcPrefix + "Data.PartInfo.ToDatabase.PenBarcodes[0]"
			, opcPrefix + "Data.PartInfo.ToDatabase.PenBarcodes[1]"
			, opcPrefix + "Data.PartInfo.ToDatabase.PenBarcodes[2]"
			, opcPrefix + "Data.PartInfo.ToDatabase.PenBarcodes[3]"
			, opcPrefix + "Data.PartInfo.ToDatabase.PenBarcodes[4]"
			, opcPrefix + "Data.PartInfo.ToDatabase.MaterialID[0]"
			, opcPrefix + "Data.PartInfo.ToDatabase.MaterialID[1]"
			, opcPrefix + "Data.PartInfo.ToDatabase.MaterialID[2]"
			, opcPrefix + "Data.PartInfo.ToDatabase.MaterialID[3]"
			, opcPrefix + "Data.PartInfo.ToDatabase.MaterialID[4]"			
			, opcPrefix + "Data.FailureType"
			, opcPrefix + "Data.RejectBarcodePrinted"
		]
		
		# Get the tag values needed for input parameters to the stored procedure
		opcValues = sdc.tag.read(opcTagPaths, True)
		
		TransactionId = opcValues[0]
		ShopOrderId = opcValues[1]
		JobId = opcValues[2]
		HeadNumber = opcValues[3]
		LegNumber = legNum
		ActualWeight = opcValues[4]
		BulkTrayTraceability_1 = opcValues[5]
		BulkTrayTraceability_2 = opcValues[6]
		BulkTrayTraceability_3 = opcValues[7]
		BulkTrayTraceability_4 = opcValues[8]
		BulkTrayTraceability_5 = opcValues[9]
		PenPartNumber_1 = opcValues[10]
		PenPartNumber_2 = opcValues[11]
		PenPartNumber_3 = opcValues[12]
		PenPartNumber_4 = opcValues[13]
		PenPartNumber_5 = opcValues[14]
		MaterialID_US1 = opcValues[15]
		MaterialID_US2 = opcValues[16]
		MaterialID_US3 = opcValues[17]
		MaterialID_US4 = opcValues[18]
		MaterialID_US5 = opcValues[19]
		RejectCode = opcValues[20]
		RejectBarcode = opcValues[21]
		#print "Material IDs: 1: " + str(MaterialID_US1) + ", 2: " + str(MaterialID_US2) + ", 3: " + str(MaterialID_US3) + ", 4: " + str(MaterialID_US4) + ", 5: " + str(MaterialID_US5)
		#print "RejectCode: " + str(RejectCode) + ", RejectBarcode: " + RejectBarcode
		
		newTransactionId = (TransactionId % 10000) + 1
		sdc.tag.write([pathPrefix + "Handshake/TransactionID"], [newTransactionId], True)
		
		call = system.db.createSProcCall("sdcSP_JobInfeedUnload")

		call.registerOutParam(1, system.db.INTEGER) #NewID
		call.registerOutParam(2, system.db.INTEGER) #intErrorCode
		call.registerOutParam(3, system.db.VARCHAR) #CustomErrMsg

		call.registerInParam(4, system.db.INTEGER, ShopOrderId)
		call.registerInParam(5, system.db.INTEGER, JobId)
		call.registerInParam(6, system.db.TINYINT, LegNumber)
		call.registerInParam(7, system.db.TINYINT, HeadNumber)
		call.registerInParam(8, system.db.FLOAT, ActualWeight)
		call.registerInParam(9, system.db.NVARCHAR, BulkTrayTraceability_1)
		call.registerInParam(10, system.db.NVARCHAR, BulkTrayTraceability_2)
		call.registerInParam(11, system.db.NVARCHAR, BulkTrayTraceability_3)
		call.registerInParam(12, system.db.NVARCHAR, BulkTrayTraceability_4)
		call.registerInParam(13, system.db.NVARCHAR, BulkTrayTraceability_5)
		call.registerInParam(14, system.db.NVARCHAR, PenPartNumber_1)
		call.registerInParam(15, system.db.NVARCHAR, PenPartNumber_2)
		call.registerInParam(16, system.db.NVARCHAR, PenPartNumber_3)
		call.registerInParam(17, system.db.NVARCHAR, PenPartNumber_4)
		call.registerInParam(18, system.db.NVARCHAR, PenPartNumber_5)
		call.registerInParam(19, system.db.INTEGER, MaterialID_US1)
		call.registerInParam(20, system.db.INTEGER, MaterialID_US2)
		call.registerInParam(21, system.db.INTEGER, MaterialID_US3)
		call.registerInParam(22, system.db.INTEGER, MaterialID_US4)
		call.registerInParam(23, system.db.INTEGER, MaterialID_US5)
		call.registerInParam(24, system.db.INTEGER, RejectCode)
		call.registerInParam(25, system.db.NVARCHAR, RejectBarcode)
		
		system.db.execSProcCall(call)
		  
		# Get the output parameters
		NewId = call.getOutParamValue(1)
		ErrorCode = call.getOutParamValue(2)
		ErrMsg = call.getOutParamValue(3)

		writeValues[0] = NewId
		writeValues[1] = ErrorCode
		writeValues[2] = ErrMsg
		if (ErrorCode != 0):
			print "Unload from Infeed Leg #" + leg + " stored procedure failed: " + ErrMsg
		else:
			#print "Unload from Infeed Leg #" + leg + " stored procedure succeeded: " + ErrMsg
			writeValues[3] = False
			writeValues[4] = True
	except java.lang.Throwable, e:
		# Handle the java exception
		print "Unload from Infeed - Leg #" + leg + ". Java exception occurred:" + str(e)
		print "Cause: " + str(e.cause)
		myLogger.error(traceback.format_exc())
	except Exception, e:
		# Handle Python Exceptions
		print "Unload from Infeed - Leg #" + leg + ". Python exception occurred:" + str(e)
		myLogger.error(traceback.format_exc())
	finally:
		sdc.tag.write(writePaths, writeValues, True)
		endTime = System.nanoTime()
		exeTime = 0.000001 * (endTime - startTime)
		#print "Unload from Infeed - Leg #{}, JobID:{}, {}. {:.1f}ms.".format(legNum, JobId, RejectBarcode, exeTime)
		#print "Unload from Infeed Leg #" + leg + " function completed."